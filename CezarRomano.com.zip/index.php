<!DOCTYPE html>
<html lang="pt-br">

<head>
	<title></title>
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/geral.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<script src="https://s.codigofonte.com.br/wp-content/js/codigofonte-bar.js"></script>



</head>

<body>
	<!--MENU COM LOGOS E LINKS-->
	<header class="navbar-wrapper">
		<nav class="navbar navbar-default menu">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#Mymen">
			        	<span class="sr-only">Toggle navigation</span>
			        	<span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
	      			</button>
					<a class="navbar-brand" href="#"><img src="img/logo.png"  class="img-responsive logo" alt="Cezar-Romano" width="160"></a>
				</div>
				<div class="collapse navbar-collapse" id="Mymen">
					<ul class="nav navbar-nav navbar-right">
						<li class="text-center active-menu item-menu"><a href="#home" class="scrollSuave" class="itens"> Home</a></li>
						<li class="text-center item-menu"><a href="#section-sobre" class="scrollSuave" class="itens ">Sobre</a></li>
						<li class="text-center item-menu"><a href="pag/ingressos.php" target="_blank" class="itens"> Contato</a></li>
					</ul>
				</div>
			</div>
		</nav>
	</header>
	<!--FIM DO MENU COM LOGOS E LINKS-->

	<!--SECTION COM OS BANNERS-->
	<section id="home">
		<div id="myCarousel" class="carousel slide">
			<div class="carousel-inner">
				<!-- Wrapper for slides -->
				<div class="item active">
					<img src="img/img-slider/img-1.jpg" alt="..." class="img-responsive" style="width: 100%;">
					<div class="carousel-caption">
					</div>
				</div>

				<div class="item">
					<img src="img/img-slider/img-2.jpg" alt="..." class="img-responsive" style="width: 100%;">
					<div class="carousel-caption">
					</div>
				</div>

			</div>
			<!-- Controls -->
			<a class="left carousel-control" href="#myCarousel" data-slide="prev">
			    <span class="icon-prev"></span>
			  </a>
			<a class="right carousel-control" href="#myCarousel" data-slide="next">
			    <span class="icon-next"></span>
			  </a>
		</div>
	</section>
	<!--FIM SECTION COM BANNERS-->

	<!-- SISTEMA DE BUSCA -->
	<section class="section section-busca">
		<div class="row">
			<div class="col-md-12">
				<form method="POST" action="pag/func_av.php">
					<div class="col-md-3">
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-12 control-label padding-label">Tipo</label>
							<div class="col-sm-12">
								<select class="form-control select-padrao" name="tipoTop" required="" id="tipoTop" onchange="ChamarLink();">
											<option class="option-select-padrao" value="padrao">Selecione o tipo de imóvel</option>
											<option class="option-select-padrao" value="comercial">Comercial</option>
											<option class="option-select-padrao" value="residencial">Residencial</option>
											<option class="option-select-padrao" value="rural">Rural</option>
											<option class="option-select-padrao" value="terreno">Terreno</option>

										</select>
							</div>
						</div>



					</div>
					<div class="col-md-4" id="comercial">
						Conectado, guys
					</div>
					<div class="col-md-9" id="residencial">
						<br>
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-12 control-label padding-label">Tipo de Negócio</label>
							<div class="col-sm-12">
								<select class="form-control select-padrao" name="negocio" required="" id="negocio">
											<option class="option-select-padrao" value="padrao">Selecione o tipo de Negócio</option>
											<option class="option-select-padrao" value="aluguel">Aluguel</option>
											<option class="option-select-padrao" value="venda">Venda</option>
									</select>
							</div>
						</div>
						<br>
							<div class="form-group">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Imóveis</label>
									<div class="col-sm-12">
										<select class="form-control select-padrao" name="tipoResidencial" required="" id="tipoResidencial">
											<option class="option-select-padrao" value="padrao">Selecione o tipo de imóvel</option>
											<option class="option-select-padrao" value="apartamento">Apartamento</option>
											<option class="option-select-padrao" value="casa">Casa</option>
											<option class="option-select-padrao" value="cobertura">Cobertura</option>
											<option class="option-select-padrao" value="kitnet">Kitnet</option>
											<option class="option-select-padrao" value="sobrado">Sobrado</option>
									</select>
									</div>
							</div>
							<br>
							<div class="form-group">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor R$</label>
									<div class="col-sm-12">
										<input type="text" class="form-control select-padrao dinheiro" name="valorResidencial" required="" id="money" onKeyPress="return(MascaraMoeda(this,'.',',',event))">

									</select>
									</div>
							</div>
							<div class="form-group">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Endereço</label>
									<div class="col-sm-12">
								
										<div class="col-md-4">
											<label for="inputPassword3" class="col-sm-12 control-label">Rua</label>
											<input type="text" class="form-control select-padrao" name="rua" required="">
										</div>
										
										<div class="col-md-4">
											<label for="inputPassword3" class="col-sm-12 control-label">Número</label>
											<input type="number" class="form-control select-padrao col-md-4" name="numero" required="">
										</div>
										
										<div class="col-md-4">
											<label for="inputPassword3" class="col-sm-12 control-label">Bairro</label>
										<input type="text" class="form-control select-padrao col-md-4" name="bairro" required="">
										</div>
										<div class="col-md-4">
											<label for="inputPassword3" class="col-sm-12 control-label">Estado</label>
											<select class="form-control select-padrao" name="estado" required="" id="estado"></select>
										</div>
										<div class="col-md-4">
											<label for="inputPassword3" class="col-sm-12 control-label">Cidade</label>
											<select class="form-control select-padrao" name="cidade" required="" id="cidade"></select>
										</div>
									</select>
									</div>
							</div>
						</div>


				</form>
			</div>
		</div>
	</section>
	<!-- FIM SISTEMA DE BUSCA -->
	<script src="js/js.js"></script>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.js"></script>
	<script type="text/javascript" src="http://cidades-estados-js.googlecode.com/files/cidades-estados-v0.2.js"></script> 

	<script text="javascript">
		function ChamarLink() {
        var valorCombo = document.getElementById("tipoTop").value;
				
				if(valorCombo == "padrao"){
					$('#comercial').hide('slow');
					$('#residencial').hide('slow');
				}else if(valorCombo == "comercial"){
					$('#comercial').show('slow');
					$('#residencial').hide('slow');
				}else if(valorCombo == "residencial"){
					$('#comercial').hide('slow');
					$('#residencial').show('slow');
				}
        
    }
	</script>
	<script language="javascript">
//-----------------------------------------------------
//Funcao: MascaraMoeda
//Sinopse: Mascara de preenchimento de moeda
//Parametro:
//   objTextBox : Objeto (TextBox)
//   SeparadorMilesimo : Caracter separador de milésimos
//   SeparadorDecimal : Caracter separador de decimais
//   e : Evento
//Retorno: Booleano
//Autor: Gabriel Fróes - www.codigofonte.com.br
//-----------------------------------------------------
function MascaraMoeda(objTextBox, SeparadorMilesimo, SeparadorDecimal, e){
    var sep = 0;
    var key = '';
    var i = j = 0;
    var len = len2 = 0;
    var strCheck = '0123456789';
    var aux = aux2 = '';
    var whichCode = (window.Event) ? e.which : e.keyCode;
    if (whichCode == 13) return true;
    key = String.fromCharCode(whichCode); // Valor para o código da Chave
    if (strCheck.indexOf(key) == -1) return false; // Chave inválida
    len = objTextBox.value.length;
    for(i = 0; i < len; i++)
        if ((objTextBox.value.charAt(i) != '0') && (objTextBox.value.charAt(i) != SeparadorDecimal)) break;
    aux = '';
    for(; i < len; i++)
        if (strCheck.indexOf(objTextBox.value.charAt(i))!=-1) aux += objTextBox.value.charAt(i);
    aux += key;
    len = aux.length;
    if (len == 0) objTextBox.value = '';
    if (len == 1) objTextBox.value = '0'+ SeparadorDecimal + '0' + aux;
    if (len == 2) objTextBox.value = '0'+ SeparadorDecimal + aux;
    if (len > 2) {
        aux2 = '';
        for (j = 0, i = len - 3; i >= 0; i--) {
            if (j == 3) {
                aux2 += SeparadorMilesimo;
                j = 0;
            }
            aux2 += aux.charAt(i);
            j++;
        }
        objTextBox.value = '';
        len2 = aux2.length;
        for (i = len2 - 1; i >= 0; i--)
        objTextBox.value += aux2.charAt(i);
        objTextBox.value += SeparadorDecimal + aux.substr(len - 2, len);
    }
    return false;
}
</script>
<script type="text/javascript">
    window.onload = function() {
        new dgCidadesEstados( 
            document.getElementById('estado'), 
            document.getElementById('cidade'), 
            true
        );
    }
</script>
	
</body>

</html>