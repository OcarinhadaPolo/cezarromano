<?php

	if(isset($_POST['enviarContato'])){
		extract($_POST);

		include '../config/config.php';

		$q = "INSERT INTO contatos VALUES ('', '$nome','$email','$telefone','$mensagem')";
		$qq = $mysqli->query($q);

		if($qq){
			echo "<script> alert('Mensagem enviada com sucesso!');window.location='../index.php';</script>";
		}else{
			echo "<script> alert('Erro ao enviar mensagem!');window.location='../index.php';</script>";

		}

	}

?>