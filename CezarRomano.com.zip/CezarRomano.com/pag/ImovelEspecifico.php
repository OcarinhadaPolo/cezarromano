<?php
	extract($_GET);
	extract($_POST);
	include '../config/config.php';
	include_once ('Redimensiona.php');

	if(!(isset($idImovel))){
		echo "<script>alert('código do imóvel não encontrado');window.location='../index.php';</script>";
	}


	if(isset($idImovel)){
		$TestaComercial = $mysqli->query("SELECT * FROM cadastroimovelcomercial WHERE codigo = '$idImovel' AND status = 'ativo'");
		$TestaResidecial = $mysqli->query("SELECT * FROM cadastroimovelresidencial WHERE codigo = '$idImovel' AND status = 'ativo'");
		$TestaRural = $mysqli->query("SELECT * FROM cadastrorural WHERE codigo = '$idImovel' AND status = 'ativo'");
		$TestaTerreno = $mysqli->query("SELECT * FROM cadastroterreno WHERE codigo = '$idImovel' AND status = 'ativo'");

		$contComercial = mysqli_num_rows($TestaComercial);
		$contResidencial = mysqli_num_rows($TestaResidecial);
		$contRural = mysqli_num_rows($TestaRural);
		$contTerreno = mysqli_num_rows($TestaTerreno);

		if($contComercial <= 0){
			echo "<script>alert('Imóvel não disponível');window.location='../index.php';</script>";
		}else if($contResidencial <= 0){
			echo "<script>alert('Imóvel não disponível');window.location='../index.php';</script>";
	
		}else if($contTerreno <= 0){
			echo "<script>alert('Imóvel não disponível');window.location='../index.php';</script>";
		}else if($contRural <= 0){
			echo "<script>alert('Imóvel não disponível');window.location='../index.php';</script>";
		}

		if($contComercial > 0){
			$TipoImovel = "comercial";
		}else if($contResidencial > 0){
			$TipoImovel = "residencial";
		}else if($contRural > 0){
			$TipoImovel = "rural";
		}else if($contTerreno > 0){
			$TipoImovel = "terreno";
		}else{
			$TipoImovel = "Indefinido";
		}

		echo "$TipoImovel";

		if($TipoImovel == "comercial"){
			while($row = mysqli_fetch_array($TestaComercial)){
				$negocio = $row['negocio'];
				$tipo = $row['tipo'];
				$valor = $row['valor'];
				$idEndereco = $row['idEndereco'];
				$idProprietario = $row['idProprietario'];
				$observacoes = $row['observacoes'];
				$areaConstruida = $row['areaConstruida'];
				$areaTerreno = $row['areaTerreno'];
				$fotos = $row['fotos'];
				

				$qEndereco = $mysqli->query("SELECT bairro FROM enderecos WHERE idEndereco = '$idEndereco'");
				while($roww = mysqli_fetch_array($qEndereco)){$bairro = $roww['bairro'];}


				$foto = explode('@', $fotos);
				$contaFotos = count($foto) -1 ;

				$Topicos = explode(';', $observacoes);
				$contaTopico = count($Topicos) - 1;

				$diretorio = "../img/imoveis/comercial/";

				$nVisu = $row['visualizacoes'];
				$nVisu++;
				$contarVisu = $mysqli->query("UPDATE cadastroimovelcomercial SET visualizacoes = '$nVisu' WHERE codigo='$idImovel'");
			}
		}else if($TipoImovel == "residencial"){
			while($row = mysqli_fetch_array($TestaResidecial)){
				$negocio = $row['negocio'];
				$tipo = $row['tipo'];
			    $valor = $row['valor'];
			    $idEndereco = $row['idEndereco'];
			  	$idProprietario = $row['idProprietario'];
			    $numeroQuartos = $row['numeroQuartos'];
			    $numeroBanheiros = $row['numeroBanheiros'];
			    $numeroSuites = $row['numeroSuites'];
			    $observacoes = $row['observacoes'];
			    $areaConstruida = $row['areaConstruida'];
			    $areaTerreno = $row['areaTerreno'];
			    $fotos = $row['fotos'];

			    $qEndereco = $mysqli->query("SELECT bairro FROM enderecos WHERE idEndereco = '$idEndereco'");
				while($roww = mysqli_fetch_array($qEndereco)){$bairro = $roww['bairro'];}

			    $foto = explode('@', $fotos);
				$contaFotos = count($foto) -1 ;

				$Topicos = explode(';', $observacoes);
				$contaTopico = count($Topicos) - 1;

				$diretorio = "../img/imoveis/residencial/";


				$nVisu = $row['visualizacoes'];
				$nVisu++;
				$contarVisu = $mysqli->query("UPDATE cadastroimovelresidencial SET visualizacoes = '$nVisu' WHERE codigo='$idImovel'");
			}
		} else if($TipoImovel == "rural"){
			while($row = mysqli_fetch_array($TestaRural)){
				$negocio = $row['negocio'];
				$tipo = $row['tipo'];
				$valor = $row['valor'];
				$idEndereco = $row['idEndereco'];
				$idProprietario = $row['idProprietario'];
		        $areaConstruidaH = $row['areaConstruidaH'];
		        $areaTerrenoH = $row['areaTerrenoH'];
		        $areaConstruidaA = $row['areaConstruidaA'];
		        $areaTerrenoA = $row['areaTerrenoA'];
				$observacoes = $row['observacoes'];
				$fotos = $row['fotos'];

				$qEndereco = $mysqli->query("SELECT bairro FROM enderecos WHERE idEndereco = '$idEndereco'");
				while($roww = mysqli_fetch_array($qEndereco)){$bairro = $roww['bairro'];}

				$foto = explode('@', $fotos);
				$contaFotos = count($foto) -1 ;

				$Topicos = explode(';', $observacoes);
				$contaTopico = count($Topicos) - 1;

				$diretorio = "../img/imoveis/rural/";


				$nVisu = $row['visualizacoes'];
				$nVisu++;
				$contarVisu = $mysqli->query("UPDATE cadastrorural SET visualizacoes = '$nVisu' WHERE codigo='$idImovel'");
			}	
		}else if($TipoImovel == "terreno"){
			while($row = mysqli_fetch_array($TestaTerreno)){
				$negocio = $row['negocio'];
				$tipo = $row['tipo'];
				$valor = $row['valor'];
				$idEndereco = $row['idEndereco'];
				$idProprietario = $row['idProprietario'];
				$observacoes = $row['observacoes'];
				$area= $row['areaTerreno'];
				$fotos = $row['fotos'];

				$qEndereco = $mysqli->query("SELECT bairro FROM enderecos WHERE idEndereco = '$idEndereco'");
				while($roww = mysqli_fetch_array($qEndereco)){$bairro = $roww['bairro'];}

				$foto = explode('@', $fotos);
				$contaFotos = count($foto) - 1;

				$Topicos = explode(';', $observacoes);
				$contaTopico = count($Topicos) - 1;



				$diretorio = "../img/imoveis/terreno/";


				$nVisu = $row['visualizacoes'];
				$nVisu++;
				$contarVisu = $mysqli->query("UPDATE cadastroterreno SET visualizacoes = '$nVisu' WHERE codigo='$idImovel'");
			}
		}



?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Imóvel </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.css" >
		<link rel="stylesheet" type="text/css" href="../css/geral.css">
		<link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
		  <style>
    
    .galer {
      max-width: 100%;
    
    }
    ul {
      list-style: none;
      margin-bottom: 1.5em;
    }
    .main-image {
     max-width: 100%;
      margin-bottom: 0.75em;
    }
    .thumbnails li img {
    	max-width: 100%;
    	padding: 3px;

    }
  </style>
	</head>
	<body style="color: #fff">


		<nav class="navbar navbar-default menu navbar-expand-lg navbar-dark bg-dark navbar-fixed-top" id="mainNav">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand js-scroll-trigge" href="#page-top"><img src="../img/logo.png"  class="img-responsive logo" alt="Cezar-Romano" width="160"></a>
				</div>
				<div class="collapse navbar-collapse" id="navbarResponsive">
					<ul class="nav navbar-nav ml-auto navbar-right">
						<li class="nav-item text-center item-menu">
							<a class="nav-link itens js-scroll-trigger scrollSuave" href="../index.php">Buscar Imóveis</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		<!--IMOVEL ESPECÍFICO-->
		
		 
		<section class="section especifico"> 
			<div class="row">
					<div class="col-md-12">
						<div class="col-md-5">
							<div class="main-image col-md-12">
								<?php 
									$foto1 = $diretorio.$foto[0];
								?>
								<img src="<?php echo "$foto1" ?>" alt='Foto primária' class='custom galer img-responsive fill-main'>
							</div>
							<ul class='thumbnails col-md-12'>
								<?php
									for($i = 0; $i < $contaFotos;$i++){
										$Nfoto[$i] = $diretorio.$foto[$i];
										$sofoto = $foto[$i];

	    							echo"<li><a href='$Nfoto[$i]'><img src='$Nfoto[$i]' class= 'col-md-3 col-sm-3 col-xs-3 fill-thumb img-responsive galer' alt='Thumbnails'></a></li>";
									
									}
								 ?>
							 </ul>
						</div>
						

						<!--IMOVEL COMERCIAL ESPECIFICO-->
						<?php
							if($TipoImovel == "comercial"){

						?>
							<div class="col-md-7 ">
								<h2 class="text-center titulos-top-imovel"> <?php echo "$negocio"; ?> / <?php echo "$tipo"; ?></h2>
								<h4 class="text-center titulos-top-imovel"><?php echo "$idImovel"; ?></h4>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Valor</span>
									<span class="sub-topico">R$ <?php echo "$valor"; ?></span></h2>

									<h2 class="col-md-6"><span class="topico">Área Terreno</span>
									<span class="sub-topico"><?php echo "$areaTerreno"; ?> m²</span></h2>


								</div>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Cidade</span>
									<span class="sub-topico">Eunápolis - BA</span></h2>
									<h2 class="col-md-6"><span class="topico">Área Construída</span>
									<span class="sub-topico"><?php echo "$areaConstruida"; ?> m²</span></h2>

								</div>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Bairro</span>
									<span class="sub-topico"><?php echo "$bairro"; ?></span></h2>

								</div>
								<div class="col-md-12  ObFormat">

									<h2 class="col-md-12"><span class="topico">Observações</span>
									<span class="sub-topicosOb">
									<?php
									for($i = 0; $i < $contaTopico;$i++){
										$NTopico[$i] = $observacoes.$Topicos[$i];
										$soTopico = $Topicos[$i];

	    							echo" $soTopico <br>";
									
									}?>
									</span></h2>
								</div>
								<div class="col-md-12">
									<h3 class="text-white text-center"> Para mais informações: (xx) x xxxx-xxxx / email@email.com</h3>
								</div>
							</div>
						<?php
							}
						?>
						<!--FIM COMERCIAL IMOVEL ESPECIFICO-->

							<!--IMOVEL RESIDENCIAL ESPECIFICO-->
						<?php
							if($TipoImovel == "residencial"){

						?>
							<div class="col-md-7 ">
								<h2 class="text-center titulos-top-imovel"> <?php echo "$negocio"; ?> / <?php echo "$tipo"; ?></h2>
								<h4 class="text-center titulos-top-imovel"><?php echo "$idImovel"; ?></h4>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Valor</span>
									<span class="sub-topico">R$ <?php echo "$valor"; ?></span></h2>

										<h2 class="col-md-6"><span class="topico">Bairro</span>
									<span class="sub-topico"><?php echo "$bairro"; ?></span></h2>

									


								</div>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Cidade</span>
									<span class="sub-topico">Eunápolis - BA</span></h2>

									<h2 class="col-md-4"><span class="topico">Suítes</span>
									<span class="sub-topico"><?php echo "$numeroSuites"; ?></span></h2>
									

									

								</div>
								
								
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Banheiros</span>
									<span class="sub-topico"><?php echo "$numeroBanheiros"; ?></span></h2>


									<h2 class="col-md-6"><span class="topico">Quartos</span>
									<span class="sub-topico"><?php echo "$numeroQuartos"; ?></span></h2>
								</div>

								<div class="col-md-12">	
									<h2 class="col-md-6"><span class="topico">Área Terreno</span>
									<span class="sub-topico"><?php echo "$areaTerreno"; ?> m²</span></h2>

									<h2 class="col-md-6"><span class="topico">Área Construída</span>
									<span class="sub-topico"><?php echo "$areaConstruida"; ?> m²</span></h2>
								</div>
								
								<div class="col-md-12 ObFormat">

									<h2 class="col-md-12"><span class="topico">Observações</span>
									<span class="sub-topicosOb">
									<?php
									for($i = 0; $i < $contaTopico;$i++){
										$NTopico[$i] = $observacoes.$Topicos[$i];
										$soTopico = $Topicos[$i];

	    							echo" $soTopico <br>";
									
									}?>
									</span></h2>
								</div>
								<div class="col-md-12">
									<h3 class="text-white text-center"> Para mais informações: (xx) x xxxx-xxxx / email@email.com</h3>
								</div>
							</div>
						<?php
							}
						?>
						<!--FIM RESIDENCIAL IMOVEL ESPECIFICO-->


							<!--IMOVEL RURAL ESPECIFICO-->
						<?php
							if($TipoImovel == "rural"){

						?>
							<div class="col-md-7">
								<h2 class="text-center titulos-top-imovel"> <?php echo "$negocio"; ?> / <?php echo "$tipo"; ?></h2>
								<h4 class="text-center titulos-top-imovel"><?php echo "$idImovel"; ?></h4>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Valor</span>
									<span class="sub-topico">R$ <?php echo "$valor"; ?></span></h2>

								


								</div>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Cidade</span>
									<span class="sub-topico">Eunápolis - BA</span></h2>
								
									<h2 class="col-md-6"><span class="topico">Bairro</span>
									<span class="sub-topico"><?php echo "$bairro"; ?></span></h2>

								</div>
								<div class="col-md-12">
										<h2 class="col-md-6"><span class="topico">Área Construída (Hectares)</span>
									<span class="sub-topico"><?php echo "$areaConstruidaA"; ?> ha</span></h2>

									<h2 class="col-md-6"><span class="topico">Área Terreno (Hectares)</span>
									<span class="sub-topico"><?php echo "$areaTerrenoH"; ?> ha</span></h2>

								</div>
								<div class="col-md-12">
									
									<h2 class="col-md-6"><span class="topico">Área Construída (Alqueires)</span>
									<span class="sub-topico"><?php echo "$areaConstruidaA"; ?> alqueires</span></h2>
									<h2 class="col-md-6"><span class="topico">Área Terreno (Alqueires)</span>
									<span class="sub-topico"><?php echo "$areaTerrenoA"; ?> alqueires</span></h2>
								

								</div>
								<div class="col-md-12  ObFormat">

									<h2 class="col-md-12"><span class="topico">Observações</span>
									<span class="sub-topicosOb">
									<?php
									for($i = 0; $i < $contaTopico;$i++){
										$NTopico[$i] = $observacoes.$Topicos[$i];
										$soTopico = $Topicos[$i];

	    							echo" $soTopico <br>";
									
									}?>
									</span></h2>
								</div>
								<div class="col-md-12">
									<h3 class="text-white text-center"> Para mais informações: (xx) x xxxx-xxxx / email@email.com</h3>
								</div>
							</div>
						<?php
							}
						?>
						<!--FIM RURAL IMOVEL ESPECIFICO-->






						<!--IMOVEL ESPECIFICO TERRENO-->
						<?php
							if($TipoImovel == "terreno"){

						?>
							<div class="col-md-7 ">
								<h2 class="text-center titulos-top-imovel"> <?php echo "$negocio"; ?> / <?php echo "$tipo"; ?></h2>
								<h4 class="text-center titulos-top-imovel"><?php echo "$idImovel"; ?></h4>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Valor</span>
									<span class="sub-topico">R$ <?php echo "$valor"; ?></span></h2>

									<h2 class="col-md-6"><span class="topico">Área</span>
									<span class="sub-topico"><?php echo "$area"; ?> m²</span></h2>

								</div>
								<div class="col-md-12">
									<h2 class="col-md-6"><span class="topico">Bairro</span>
									<span class="sub-topico"><?php echo "$bairro"; ?></span></h2>
						
									<h2 class="col-md-6"><span class="topico">Cidade</span>
									<span class="sub-topico">Eunápolis - BA</span></h2>
								</div>
								<div class="col-md-12  ObFormat">

									<h2 class="col-md-12 "><span class="topico">Observações</span>
									<span class="sub-topicosOb">
									<?php
									for($i = 0; $i < $contaTopico;$i++){
										$NTopico[$i] = $observacoes.$Topicos[$i];
										$soTopico = $Topicos[$i];

	    							echo" $soTopico \n <br>";
									
									}?>
									</span></h2>
								</div>
								<div class="col-md-12">
									<h3 class="text-white text-center"> Para mais informações: (xx) x xxxx-xxxx / email@email.com</h3>
								</div>
							</div>
						<?php
							}
						?>
					<!--FIM IMOVEL ESPECIFICO TERRENO-->	

					</div>
				</div>
			
		</section> 


		<!-- FIM IMOVEL ESPECÍFICO-->

		<!--SECTION FAVORITOS-->
		<section class="section-favoritos" id="destaque">
			<div class="container">
				<div class="col-md-12">
					<h1 class="text-center espaco-text cor-preta">IMÓVEIS MAIS VISITADOS</h1>
				</div>
				<div class="col-md-12">
					<?php

						$qFavorito = $mysqli->query("SELECT codigo, tipo, negocio, valor, fotos,visualizacoes FROM cadastroimovelcomercial union  SELECT codigo, tipo, negocio, valor, fotos,visualizacoes FROM cadastroimovelresidencial union   SELECT codigo, tipo, negocio, valor, fotos,visualizacoes FROM cadastrorural union  SELECT codigo, tipo, negocio, valor, fotos,visualizacoes FROM cadastroterreno ORDER BY visualizacoes DESC LIMIT 6 ");



						if($qFavorito){
							while($row = mysqli_fetch_array($qFavorito)){
							$idImovel = $row['codigo'];
							$tipo = $row['tipo'];
							$negocio = $row['negocio'];
							$valor = $row['valor'];
							$fotos = $row['fotos'];

							$foto = explode('@', $fotos);
							$visualizacoes = $row['visualizacoes'];
							

							$TestaComercial = $mysqli->query("SELECT * FROM cadastroimovelcomercial WHERE codigo = '$idImovel'");
							$TestaResidecial = $mysqli->query("SELECT * FROM cadastroimovelresidencial WHERE codigo = '$idImovel'");
							$TestaRural = $mysqli->query("SELECT * FROM cadastrorural WHERE codigo = '$idImovel'");
							$TestaTerreno = $mysqli->query("SELECT * FROM cadastroterreno WHERE codigo = '$idImovel'");

							$contComercial = mysqli_num_rows($TestaComercial);
							$contResidencial = mysqli_num_rows($TestaResidecial);
							$contRural = mysqli_num_rows($TestaRural);
							$contTerreno = mysqli_num_rows($TestaTerreno);

							if($contComercial > 0){
								$TipoImovel = "comercial";
								$foto = '../img/imoveis/comercial/'.$foto[0];
							}else if($contResidencial > 0){
								$TipoImovel = "residencial";
								$foto = '../img/imoveis/residencial/'.$foto[0];

							}else if($contRural > 0){
								$TipoImovel = "rural";
								$foto = '../img/imoveis/rural/'.$foto[0];

							}else if($contTerreno > 0){
								$TipoImovel = "terreno";
								$foto = '../img/imoveis/terreno/'.$foto[0];

							}else{
								$TipoImovel = "Indefinido";
							}


					?>
								<div class="col-md-2 item-favorito cor-preta" >
									<center><a href="ImovelEspecifico.php?idImovel=<?php echo "$idImovel"; ?>"><img src="<?php echo "$foto";  ?>" class="img-responsive transparencia fill" id="f4"></a></center>
									<div class="list-group esconder" id="text4">
										<span class="list-group-item top-list">
											Código: <?php echo "$idImovel"; ?>
										</span>
										<span  class="list-group-item">Tipo: <?php echo "$tipo"; ?></span>
										<span  class="list-group-item">Negócio: <?php echo "$negocio"; ?></span>
										<span  class="list-group-item">Valor: R$ <?php echo "$valor"; ?></span>
										<span  class="list-group-item">Visualizações: <?php echo "$visualizacoes"; ?></span>
									</div>
								</div>
					<?php
							}
						}else{
							echo "não foi";
						}

					?>
					
				</div>
			</div>
		</section>
		<!-- FIM SECTION FAVORITOS-->
		<!--RODAPÉ-->
		<section class="rodape">
			<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
			<div class="container">
				<div class="col-md-12">
					<center><ul class="social-network social-circle">

						<li><a href="#" class="icoFacebook r-social" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" class="icoGoogle r-social" title="Google +"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="#" class="icoPhone r-social" title="Telefone"><i class="fa fa-whatsapp"></i></a></li>
					</ul></center>				
				</div>
				<div class="col-md-12">
					<h6 class="text-left branco col-md-6">Telefone: (73) Xxxxx-xxxx</h6>
					<h6 class="text-right branco col-md-6">© Copyright - Todos os direitos reservados</h6>
				</div>
			</div>
		</section>
		<!--RODAPÉ-->
		<script src="../js/js.js"></script>
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.js"></script>
		<script  src = "../libs/jquery-maskmoney-master/dist/jquery.maskMoney.min.js"  type = "text/javascript " ></script>
		<script src="../js/scrolling-nav.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		  <script src="../js/jquery.simpleGal.js"></script>

		<script>
		  $(document).ready(function () {
		    $('.thumbnails').simpleGal({
		      mainImage: '.custom'
		    });
		  });
 		 </script>
	</body>
	</html>
<?php 

	}else{
		echo "<script>alert('Imóvel não encontrado');window.location='../index.php';<script>";
	}
?>