<?php
	include 'config/config.php';

 ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Cezar Romano</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/geral.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
</head>
<body onload="aparecerimage();" id="page-top" >
	<nav class="navbar navbar-default menu navbar-expand-lg navbar-dark bg-dark navbar-fixed-top" id="mainNav">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand js-scroll-trigge" href="#page-top"><img src="img/logo.png"  class="img-responsive logo" alt="Cezar-Romano" width="160"></a>
			</div>
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="nav navbar-nav ml-auto navbar-right">
					<li class="nav-item text-center item-menu">
						<a class="nav-link itens js-scroll-trigger scrollSuave" href="#busca">Buscar Imóveis</a>
					</li>
					<li class="nav-item text-center item-menu">
						<a class="nav-link itens js-scroll-trigger scrollSuave" href="#destaque">Imóveis em destaque</a>
					</li>
					<li class="nav-item text-center item-menu">
						<a class="nav-link itens js-scroll-trigger scrollSuave" href="#sobre">Sobre</a>
					</li>
					<li class=" nav-item text-center  item-menu">
						<a class="nav-link itens js-scroll-trigger scrollSuave" id="itemcontato"  href="#contato" > Contato</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>


	<!--FIM DO MENU COM LOGOS E LINKS-->

	

	<!-- SISTEMA DE BUSCA -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content ">
      <div class="modal-header  modal-perso">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center" id="myModalLabel">Guia de Busca dos imóveis</h4>
      </div>
      <div class="modal-body modal-perso">
       	<ul class="list-group sem-ponto">
		  <li class="text-justify itens-lista-dicas">
		    <span class="numero-lista">1</span>
		    	Escolha o tipo de imóvel que deseja (<span class="subilinhado">Comercial </span>, <span class="subilinhado">Residencial </span>, <span class="subilinhado">Rural</span> ou <span class="subilinhado">Terreno</span>), caso tenha algo específico opte por buscar pelo <span class="subilinhado">código</span>!
		  </li>
		  <li class="text-justify itens-lista-dicas">
		    <span class="numero-lista">2</span>
		    	Após a escolha do tipo, você terá 3 opções (<span class="subilinhado">Não preencher nenhuma informação </span>, que resultará na busca de todos imóveis do tipo selecionado <span class="subilinhado">Preencher todas informções </span>, que te dará uma busca mais precisa  ou <span class="subilinhado">Preencher apenas, bairro, Valor Mínimo e Valor Máximo</span>).
		  </li>

		  <li class="text-justify itens-lista-dicas">
		    <span class="numero-lista">3</span>
		    	Caso tenha optado pela busca por código basta <span class="subilinhado">informar o código do imóvel </span>, que deverá ser fornecido pelo corretor imobiliário, caso não possua, entre em contato.
		  </li>
		</ul>
      </div>
      <div class="modal-footer modal-perso">
        <button type="button" class="btn bt-modal" data-dismiss="modal">Fechar tutorial</button>
      </div>
    </div>
  </div>
</div>
	<!--SECTION COM OS BANNERS-->
	<section class="section" id="home">
		<div id="carousel-example-generic" class="carousel slide slider" data-ride="carousel">
			<ol class="carousel-indicators">
			<?php
				$qSlide = $mysqli->query("SELECT * FROM slide");
				$i = 0;
				while($row = mysqli_fetch_array($qSlide)){
					$id = $row['idSlide'];

					if($i == 0){
						$class = "active";
						$dataslide = "$id";
					}else{
						$class= null;
						$dataslide = "$id";
					}

					

			?>
			
				<li data-target="#carousel-example-generic" data-slide-to="<?php echo "$i"; ?>" class="<?php echo "$class"; ?>">
					
				</li>
				

			<?php
					$i++;
				}

			?>
			</ol>

			
			<div class="carousel-inner" role="listbox">
				<?php
					$i2 = 1;
					$Qslide = $mysqli->query("SELECT * FROM slide");
					while($row2 = mysqli_fetch_array($Qslide)){
						$caminho = $row2['caminho'];
						if($i2 == 1){
							$classe = "item active";
						}else{
							$classe = "item";
						}

					$i2++;
				?>

				<div class="<?php echo "$classe";?>">
					<img src="img/img-slider/<?php echo "$caminho"; ?>" class="img-responsive">
				</div>
				<?php
					}

				?>
			</div>

			
			<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>


	</section>
	<!--FIM SECTION COM BANNERS-->
	<section class="section section-busca" id="busca">
		<div class="container">
			<div class="botao"><button type="button"  data-toggle="modal" data-target="#myModal">Mostrar Tutorial</button></div>
			<div class="col-md-11">
				<h2 class="text-center espaco-text  bold">BUSCAR IMÓVEIS</h2>
			</div>
			<div class="col-md-3">
				<form method="POST" action="pag/buscar.php">
					<div class="col-md-12">
						<div class="form-group">
							<label for="inputPassword3" class="col-sm-12 control-label padding-label">Busca Específica</label>
							<div class="col-sm-12">
								<select class="form-control select-padrao col-md-12" name="tipoTop" required="" id="tipoTop" onchange="ChamarLink();">
									<option class="option-select-padrao" value="padrao">Tipo do Imóvel</option>
									<option class="option-select-padrao" value="comercial">Comercial</option>
									<option class="option-select-padrao" value="residencial">Residencial</option>
									<option class="option-select-padrao" value="rural">Rural</option>
									<option class="option-select-padrao" value="terreno">Terreno</option>

								</select>
							</div>
						</div>
					</div>
				</div>
				<!-- BUSCA COMERCIAL -->
				<div class="col-md-9" id="comercial">
					<div class="form-group">
						<div class="col-md-12">
							<div class="col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Tipo de Negócio</label>
								<select class="form-control select-padrao" name="negocioComercial" required="" id="negocio">
									<option class="option-select-padrao" value="aluguel">Aluguel</option>
								</select>
							</div>
							<div class="col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Imóveis</label>
								<select class="form-control select-padrao" name="tipoComercial" required="" id="tipoComercial">
									<option class="option-select-padrao" value="padrao">Todos</option>
									<option class="option-select-padrao" value="sala">Sala</option>
									<option class="option-select-padrao" value="lojas">Lojas</option>
									<option class="option-select-padrao" value="salaliving">Sala Living</option>
									<option class="option-select-padrao" value="galpao">Galpão</option>
									<option class="option-select-padrao" value="predio">Prédio</option>
									<option class="option-select-padrao" value="pontocomercial">Ponto Comercial</option>
									<option class="option-select-padrao" value="andarcomercial">Andar Comercial</option>

								</select>
							</div>
						</div>
					</div>
					<br>
					<div class="form-group">
						<div class="col-sm-12 col-xs-12">
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Cidade</label>
								<select class="form-control select-padrao" name="cidadeComercial" required="" id="cidade">
									<option class="option-select-padrao" value="Eunápolis">Eunapolis</option>
								</select>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label class="col-sm-12 control-label padding-label">Bairro</label>
								<select class="form-control select-padrao" name="bairroComercial" id="bairro">
									<option class="option-select-padrao" value="padrao">Todos</option>
									<option class="option-select-padrao" value="Alecrim">Alecrim</option>
									<option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
									<option class="option-select-padrao" value="Centauro">Centauro</option>
									<option class="option-select-padrao" value="Centro">Centro</option>
									<option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
									<option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
									<option class="option-select-padrao" value="Itapuã">Itapuã</option>
									<option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
									<option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
									<option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
									<option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
									<option class="option-select-padrao" value="Motor">Motor</option>
									<option class="option-select-padrao" value="Pequi">Pequi</option>
									<option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
									<option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
									<option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
									<option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
									<option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
									<option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
									<option class="option-select-padrao" value="Urbis 1">Urbis I</option>
									<option class="option-select-padrao" value="Urbis 2">Urbis II</option>
									<option class="option-select-padrao" value="Urbis 3">Urbis III</option>
									<option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
									<option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
									<option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
									<option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
									<option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>


								</select>


							</div>

						</div>
					</div>
					<div class="form-group">		
						<div class="col-sm-12 col-xs-12">
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label class="col-sm-12 control-label padding-label">Valor Mínimo R$</label>
								<input type="text" class="form-control select-padrao dinheiro" name="valorMinimoComercial" id="money" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
							</div>	
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label class="col-sm-12 control-label padding-label">Valor Máximo R$</label>
								<input type="text" class="form-control select-padrao dinheiro" name="valorMaximoComercial" id="money2" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="col-md-12">
							<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
							<button class="bt-principal col-md-12 col-sm-12 col-xs-12" name="bt-comercial">BUSCAR</button>
						</div>
					</div>
				</div>		

				<!-- FIM DA BUSCA COMERCIAL -->

				<!-- BUSCA RESIDENCIAL --> 
				<div class="col-md-9" id="residencial">

					<div class="form-group">
						<div class="col-md-12">
							<div class="col-sm-6 col-md-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Tipo de Negócio</label>
								<select class="form-control select-padrao" name="negocioResidencial" required="" id="negocio">
									<option class="option-select-padrao" value="padrao">Selecione o tipo de Negócio</option>
									<option class="option-select-padrao" value="Aluguel">Aluguel</option>
									<option class="option-select-padrao" value="Venda">Venda</option>
								</select>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Imóveis</label>
								<select class="form-control select-padrao" name="tipoResidencial" required="" id="tipoResidencial">
									<option class="option-select-padrao" value="padrao">Selecione o tipo de imóvel</option>
									<option class="option-select-padrao" value="Apartamento">Apartamento</option>
									<option class="option-select-padrao" value="Casa">Casa</option>
									<option class="option-select-padrao" value="Cobertura">Cobertura</option>
									<option class="option-select-padrao" value="Kitnet">Kitnet</option>
									<option class="option-select-padrao" value="Sobrado">Sobrado</option>
								</select>
							</div>
						</div>
					</div>


					<div class="form-group">
						<div class="col-sm-12 col-xs-12">
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Cidade</label>
								<select class="form-control select-padrao" name="cidadeResidencial" required="" id="cidade">
									<option class="option-select-padrao" value="Eunápolis">Eunapolis</option>
								</select>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Bairro</label>
								<select class="form-control select-padrao" name="bairroResidencial" required="" id="bairro">
									<option class="option-select-padrao" value="padrao">Selecione o Bairro</option>
									<option class="option-select-padrao" value="Alecrim">Alecrim</option>
									<option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
									<option class="option-select-padrao" value="Centauro">Centauro</option>
									<option class="option-select-padrao" value="Centro">Centro</option>
									<option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
									<option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
									<option class="option-select-padrao" value="Itapuã">Itapuã</option>
									<option class="option-select-padrao" value="Jardins de eunapolis">Jardins De Eunápolis</option>
									<option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
									<option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
									<option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
									<option class="option-select-padrao" value="Motor">Motor</option>
									<option class="option-select-padrao" value="Pequi">Pequi</option>
									<option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
									<option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
									<option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
									<option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
									<option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
									<option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
									<option class="option-select-padrao" value="Urbis 1">Urbis I</option>
									<option class="option-select-padrao" value="Urbis 2">Urbis II</option>
									<option class="option-select-padrao" value="Urbis 3">Urbis III</option>
									<option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
									<option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
									<option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
									<option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
									<option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>


								</select>


							</div>

						</div>
					</div>

					<div class="form-group">		
						<div class="col-sm-12 col-xs-12">
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Mínimo R$</label>
								<input type="text" class="form-control select-padrao dinheiro" name="valorMinimoResidencial" id="money3" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
							</div>	
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Máximo R$</label>
								<input type="text" class="form-control select-padrao dinheiro" name="valorMaximoResidencial" id="money4" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-12 col-xs-12">
							<div class="col-md-4 col-sm-4 col-xs-4">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Nº Quartos</label>
								<input type="number" class="form-control select-padrao " name="Nquartos" min="1" value="1" />
							</div>
							<div class="col-md-4 col-sm-4 col-xs-4">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Nº Suítes</label>
								<input type="number" class="form-control select-padrao " name="Nsuites" min="0" value="0" />
							</div>
							<div class="col-md-4 col-sm-4 col-xs-4">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Nº Banheiros</label>
								<input type="number" class="form-control select-padrao " name="Nbanheiros" min="1" value="1"  id="banheiro" />
							</div>
						</div>
					</div>

					<div class="form-group">
						<div class="col-md-12">
							<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
							<button class="bt-principal col-md-12 col-sm-12 col-xs-12" name="bt-residencial" id="busca-residencial">BUSCAR</button>
						</div>
					</div>

				</div>
				<!-- FIM DE BUSCA RESIDENCIA -->

				<!-- BUSCA RURAL -->

				<div class="col-md-9" id="rural">
					<div class="form-group">
						<div class="col-md-12">
							<div class="col-sm-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Tipo de Negócio</label>
								<select class="form-control select-padrao" name="negocioRural" required="" id="negocio">
									<option class="option-select-padrao" value="venda">Venda</option>
								</select>
							</div>
							<div class="col-sm-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Imóveis</label>
								<select class="form-control select-padrao" name="tipoRural" required="" id="tipoRural">
									<option class="option-select-padrao" value="padrao">Selecione o tipo de Imóvel</option>
									<option class="option-select-padrao" value="fazenda">Fazenda</option>
									<option class="option-select-padrao" value="sitio">Sítio</option>
								</select>
							</div>
						</div>
						<div class="form-group">
						<div class="col-sm-12 col-xs-12">
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Cidade</label>
								<select class="form-control select-padrao" name="cidadeRural" required="" id="cidade">
									<option class="option-select-padrao" value="Eunápolis">Eunapolis</option>
								</select>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Bairro</label>
								<select class="form-control select-padrao" name="bairroRural" required="" id="bairro">
									<option class="option-select-padrao" value="padrao">Selecione o Bairro</option>
									<option class="option-select-padrao" value="Alecrim">Alecrim</option>
									<option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
									<option class="option-select-padrao" value="Centauro">Centauro</option>
									<option class="option-select-padrao" value="Centro">Centro</option>
									<option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
									<option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
									<option class="option-select-padrao" value="Itapuã">Itapuã</option>
									<option class="option-select-padrao" value="Jardins de eunapolis">Jardins De Eunápolis</option>
									<option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
									<option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
									<option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
									<option class="option-select-padrao" value="Motor">Motor</option>
									<option class="option-select-padrao" value="Pequi">Pequi</option>
									<option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
									<option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
									<option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
									<option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
									<option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
									<option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
									<option class="option-select-padrao" value="Urbis 1">Urbis I</option>
									<option class="option-select-padrao" value="Urbis 2">Urbis II</option>
									<option class="option-select-padrao" value="Urbis 3">Urbis III</option>
									<option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
									<option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
									<option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
									<option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
									<option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>


								</select>


							</div>

						</div>
					</div>
						<div class="form-group">		
							<div class="col-sm-12 col-xs-12">
								<div class="col-md-6 col-sm-6 col-xs-6">
									<label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Mínimo R$</label>
									<input type="text" class="form-control select-padrao dinheiro" name="valorMinimoRural" id="money5" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
								</div>	
								<div class="col-md-6 col-sm-6 col-xs-6">
									<label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Máximo R$</label>
									<input type="text" class="form-control select-padrao dinheiro" name="valorMaximoRural" id="money6" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="col-md-12">
							<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
							<button class="bt-principal col-md-12 col-sm-12 col-xs-12" name="bt-rural" id="busca-rural">BUSCAR</button>
						</div>
					</div>
				</div>
				<!-- FIM BUSCA RURAL -->

				<!-- BUSCA TERRENO -->
				<div class="col-md-9" id="terreno">
					<div class="form-group">
						<div class="col-md-12 col-sm-12 col-xs-12">
							
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Cidade</label>
								<select class="form-control select-padrao" name="cidadeTerreno" required="" id="cidade">
									<option class="option-select-padrao" value="Eunápolis">Eunapolis</option>
								</select>
							</div>
							<div class="col-md-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Bairro</label>
								<select class="form-control select-padrao" name="bairroTerreno" id="bairro">
									<option class="option-select-padrao" value="padrao">Todos</option>
									<option class="option-select-padrao" value="Alecrim">Alecrim</option>
									<option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
									<option class="option-select-padrao" value="Centauro">Centauro</option>
									<option class="option-select-padrao" value="Centro">Centro</option>
									<option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
									<option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
									<option class="option-select-padrao" value="Itapuã">Itapuã</option>
									<option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
									<option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
									<option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
									<option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
									<option class="option-select-padrao" value="Motor">Motor</option>
									<option class="option-select-padrao" value="Pequi">Pequi</option>
									<option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
									<option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
									<option class="option-select-padrao" value="Santa Lúcia">Santa Lucia</option>
									<option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
									<option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
									<option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
									<option class="option-select-padrao" value="Urbis 1">Urbis I</option>
									<option class="option-select-padrao" value="Urbis 2">Urbis II</option>
									<option class="option-select-padrao" value="Urbis 3">Urbis III</option>
									<option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
									<option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
									<option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
									<option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
									<option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="col-md-12">
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Mínimo R$</label>
								<input type="text" class="form-control select-padrao dinheiro" name="valorMinimoTerreno" id="money5" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
							</div>	
							<div class="col-md-6 col-sm-6 col-xs-6">
								<label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Máximo R$</label>
								<input type="text" class="form-control select-padrao dinheiro" name="valorMaximoTerreno" id="money6" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
							</div>
						</div>
					</div>
					
					<div class="form-group">
						<div class="col-md-12">
							<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
							<button class="bt-principal col-md-12 col-sm-12 col-xs-12" name="bt-terreno" id="busca-terreno">BUSCAR</button>
						</div>
					</div>
				</div>
			</form>
			<!-- FIM BUSCA TERRENO -->
			<label for="inputPassword3" class="col-sm-12 control-label padding-label"></label>
			<label for="inputPassword3" class="col-sm-12 control-label padding-label"></label>

			<!--BUSCAR POR CÓDIGO-->
			<div class="col-md-12">
				<div class="col-md-12">
					<h2 class="text-center uppercase bold">BUSCAR IMÓVEIS POR CÓDIGO</h2>
					<form  name="buscaCodigo" method="POST" action="pag/ImovelEspecifico.php">
						<div class="form-group">
							<div class="col-sm-9 col-xs-9">
								<input type="text" class="form-control diferente" name="idImovel" placeholder="Buscar por código, Ex: A001, C001, T001" id="email">
							</div>
							<div class="col-sm-3 col-xs-3">
								<button type="submit" class="bt-principal col-md-12" name="bt-codigo">BUSCAR</button>
							</div>
						</div>
					</form>
					</div>
				</div>
				<!--FIM BUSCAR POR CÓDIGO-->						
			</div>

		</section>
		<!-- FIM SISTEMA DE BUSCA -->
		
		<!--SECTION FAVORITOS-->
		<section class="section-favoritos" id="destaque">
			<div class="container">
				<div class="col-md-12">
					<h1 class="text-center espaco-text">IMÓVEIS MAIS VISITADOS</h1>
				</div>
				<div class="col-md-12">
					<?php

						$qFavorito = $mysqli->query("SELECT codigo, tipo, negocio, valor, fotos,visualizacoes FROM cadastroimovelcomercial union  SELECT codigo, tipo, negocio, valor, fotos,visualizacoes FROM cadastroimovelresidencial union   SELECT codigo, tipo, negocio, valor, fotos,visualizacoes FROM cadastrorural union  SELECT codigo, tipo, negocio, valor, fotos,visualizacoes FROM cadastroterreno ORDER BY visualizacoes DESC LIMIT 6 ");



						if($qFavorito){
							while($row = mysqli_fetch_array($qFavorito)){
							$idImovel = $row['codigo'];
							$tipo = $row['tipo'];
							$negocio = $row['negocio'];
							$valor = $row['valor'];
							$fotos = $row['fotos'];

							$foto = explode('@', $fotos);
							$visualizacoes = $row['visualizacoes'];
							

							$TestaComercial = $mysqli->query("SELECT * FROM cadastroimovelcomercial WHERE codigo = '$idImovel'");
							$TestaResidecial = $mysqli->query("SELECT * FROM cadastroimovelresidencial WHERE codigo = '$idImovel'");
							$TestaRural = $mysqli->query("SELECT * FROM cadastrorural WHERE codigo = '$idImovel'");
							$TestaTerreno = $mysqli->query("SELECT * FROM cadastroterreno WHERE codigo = '$idImovel'");

							$contComercial = mysqli_num_rows($TestaComercial);
							$contResidencial = mysqli_num_rows($TestaResidecial);
							$contRural = mysqli_num_rows($TestaRural);
							$contTerreno = mysqli_num_rows($TestaTerreno);

							if($contComercial > 0){
								$TipoImovel = "comercial";
								$foto = 'img/imoveis/comercial/'.$foto[0];
							}else if($contResidencial > 0){
								$TipoImovel = "residencial";
								$foto = 'img/imoveis/residencial/'.$foto[0];

							}else if($contRural > 0){
								$TipoImovel = "rural";
								$foto = 'img/imoveis/rural/'.$foto[0];

							}else if($contTerreno > 0){
								$TipoImovel = "terreno";
								$foto = 'img/imoveis/terreno/'.$foto[0];

							}else{
								$TipoImovel = "Indefinido";
							}


					?>
								<div class="col-md-2 item-favorito" >
									<center><a href="pag/ImovelEspecifico.php?idImovel=<?php echo "$idImovel"; ?>"><img src="<?php echo "$foto";  ?>" class="img-responsive transparencia fill" id="f4"></a></center>
									<div class="list-group esconder" id="text4">
										<span class="list-group-item top-list">
											Código: <?php echo "$idImovel"; ?>
										</span>
										<span  class="list-group-item">Tipo: <?php echo "$tipo"; ?></span>
										<span  class="list-group-item">Negócio: <?php echo "$negocio"; ?></span>
										<span  class="list-group-item">Valor: R$ <?php echo "$valor"; ?></span>
										<span  class="list-group-item">Visualizações: <?php echo "$visualizacoes"; ?></span>
									</div>
								</div>
					<?php
							}
						}else{
							echo "não foi";
						}

					?>
					
				</div>
			</div>
		</section>
		<!-- FIM SECTION FAVORITOS-->
		<!-- SECTION SOBRE -->
		<section class="section-sobre fundo-cor-padrao" id="sobre">
			<div class="container">
				<div class="col-md-12 ">
					<div class="col-md-12 texto-branco">
						<h1 class="text-center espaco-text">SOBRE</h1>
					</div>
					<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
					
					
					<div class="col-md-6 text-sobre">
						<?php 
							$qSobre = $mysqli->query("SELECT * FROM sobre");
							while ($row = mysqli_fetch_array($qSobre)){
									$textodoSobre = $row['descricao'];
						?>
								
						<p class="text-justify">
							<?php
								echo "$textodoSobre";
							}
							?>

						</p>

					</div>
					<div class="col-md-1"></div>
					<div class="col-md-5">
						<img src="img/img3.jpg" class="img-responsive borda-top">
					</div>
					<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
					<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
				</div>

			</div>

		</section>
		<!-- FIM SECTION SOBRE -->
		<!-- SECTION CONTATOS-->
		<section class="section-contatos fundo-contatos" id="contato">
			<div class="container">
				<div class="col-md-12  text-contatos">
					<div class="col-md-12">
						<h1 class="text-center espaco-text text-contatos">CONTATO</h1>
						<div class="col-md-12">
							<form method="POST" action="pag/contatar.php">
								<div class="col-md-2"></div>
								<div class="col-md-9">
									<div class="form-group">
										<label for="inputPassword3" class="col-sm-12 control-label padding-label">Nome</label>
										<input type="text" class="form-control inputs-fundo-cinza cor-branca " name="nome" required="required" />
									</div>
									<div class="form-group">
										<label for="inputPassword3" class="col-sm-12 control-label padding-label">E-mail</label>
										<input type="email" class="form-control inputs-fundo-cinza cor-branca " name="email"  required="required" />
									</div>
									<div class="form-group">
										<label for="inputPassword3" class="col-sm-12 control-label padding-label">Telefone</label>
										<input type="text" class="form-control inputs-fundo-cinza cor-branca " name="telefone" id="phone" required="required" />
									</div>
									<div class="form-group">
										<label for="inputPassword3" class="col-sm-12 control-label padding-label">Mensagem</label>
										<textarea class="form-control inputs-fundo-cinza mensagem cor-branca" name="mensagem" rows="10" required="required"></textarea>
									</div>
									<div class="form-group">
										<button type="submit" class="bt-principal col-md-12 sem-fundo" name="enviarContato">Enviar mensagem </button>

									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- FIM SECTION CONTATOS-->	

		<!--RODAPÉ-->
		<section class="rodape">
			<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
			<div class="container">
				<div class="col-md-12">
					<center><ul class="social-network social-circle">

						<li><a href="#" class="icoFacebook r-social" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" class="icoGoogle r-social" title="Google +"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="#" class="icoPhone r-social" title="Telefone"><i class="fa fa-whatsapp"></i></a></li>
					</ul></center>				
				</div>
				<div class="col-md-12">
					<h6 class="text-left branco col-md-6">Telefone: (73) Xxxxx-xxxx</h6>
					<h6 class="text-right branco col-md-6">© Copyright - Todos os direitos reservados</h6>
				</div>
			</div>
		</section>
		<!--RODAPÉ-->

		
		<script src="js/js.js"></script>
		<script src="js/jquery.js"></script>
		<script src="js/bootstrap.js"></script>
		<script src="js/scrolling-nav.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				$('#myModal').modal('show')
			});

		</script>

		<!-- Plugin JavaScript -->
		<script src="js/jquery.easing.min.js"></script>
		<script type="text/javascript">
			function aparecerimage(){
				$('#img-aparecer').show('slow');
			}
			
		</script>

		<script text="javascript">
			function ChamarLink() {
				var valorCombo = document.getElementById("tipoTop").value;

				if(valorCombo == "padrao"){
					$('#comercial').hide('slow');
					$('#residencial').hide('slow');
					$('#rural').hide('slow');
					$('#terreno').hide('slow');

				}else if(valorCombo == "comercial"){
					$('#comercial').show('slow');
					$('#residencial').hide('slow');
					$('#rural').hide('slow');
					$('#terreno').hide('slow');

				}else if(valorCombo == "residencial"){
					$('#comercial').hide('slow');
					$('#residencial').show('slow');
					$('#rural').hide('slow');
					$('#terreno').hide('slow');

				}else if(valorCombo == "rural"){
					$('#comercial').hide('slow');
					$('#residencial').hide('slow');
					$('#rural').show('slow');
					$('#terreno').hide('slow');

				}else if(valorCombo == "terreno"){
					$('#comercial').hide('slow');
					$('#residencial').hide('slow');
					$('#rural').hide('slow');
					$('#terreno').show('slow');
				}


			}
		</script>
		<script type="text/javascript">

			
			$(window).scroll(function () {
				var topWindow = $(this).scrollTop();
				if (topWindow > 70 ) {
					$('nav').addClass('nav-cor');
					$('.logo').addClass('nav-logo');
				} else{
					$('nav').removeClass('nav-cor');
					$('.logo').removeClass('nav-logo');
				}

			});
		</script>
		<script type="text/javascript">
			/*$('#f1').mouseover(function(){
     			$('#text1').show('slow');
			});
			$('#f1').mouseout(function(){
     			$('#text1').hide();
			});
	
			$('#f2').mouseover(function(){
     			$('#text2').show('slow');
			});
			$('#f2').mouseout(function(){
     			$('#text2').hide();
			});

			$('#f3').mouseover(function(){
     			$('#text3').show('slow');
			});
			$('#f3').mouseout(function(){
     			$('#text3').hide();
			});

			$('#f4').mouseover(function(){
     			$('#text4').show('slow');
			});
			$('#f4').mouseout(function(){
     			$('#text4').hide();
			});

			$('#f5').mouseover(function(){
     			$('#text5').show('slow');
			});
			$('#f5').mouseout(function(){
     			$('#text5').hide();
			});

			$('#f6').mouseover(function(){
     			$('#text6').show('slow');
			});
			$('#f6').mouseout(function(){
     			$('#text6').hide();
     		});*/





     	</script>

     </body>

     </html>