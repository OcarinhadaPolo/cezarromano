<?php
	extract($_GET);

	include '../config/config.php';

    $dir = '../img/imoveis/comercial' . DIRECTORY_SEPARATOR;
    $arquivo = isset($_FILES['foto']) ? $_FILES['foto'] : FALSE;

    

	$q  = "SELECT * FROM cadastroterreno WHERE codigo = '$idImovel'";
	$Q = $mysqli->query($q);

	while($row = mysqli_fetch_array($Q)){
		$negocio = $row['codigo'];
		$tipo = $row['tipo'];
		$valor = $row['valor'];
		$idEndereco = $row['idEndereco'];
		$idProprietario = $row['idProprietario'];
		$observacoes = $row['observacoes'];
		$area= $row['areaTerreno'];
		
		$fotos = $row['fotos'];
        $statusBD = $row['status'];

	}

	$qEndereco = "SELECT * FROM enderecos WHERE idEndereco = '$idEndereco'";
	$QEndereco = $mysqli->query($qEndereco);

	while($row1 = mysqli_fetch_array($QEndereco)){
		$numero = $row1['numero'];
		$rua = $row1['rua'];
		$bairro = $row1['bairro'];
		$cidade = "Eunápolis";
	}

	$qProprietario = "SELECT * FROM dadosproprietario WHERE idProprietario = '$idProprietario'";
	$QProprietario = $mysqli->query($qProprietario);

	while($row2 = mysqli_fetch_array($QProprietario)){
		$nome = $row2['nome'];
		$idTelefone = $row2['idTelefone'];
	}

	$qTelefone = "SELECT * FROM telefonesproprietario WHERE idTelefone = '$idTelefone'";
	$QTelefone = $mysqli->query($qTelefone);

	while($row3 = mysqli_fetch_array($QTelefone)){
		$tel = $row3['Telefone'];
	}

    

    if(isset($_POST['editarImovelTerreno'])){
        extract($_POST);


      $fotosEditar = "";

        for ($i = 0; $i < count($arquivo['size']); $i++){
            if (move_uploaded_file($arquivo['tmp_name'][$i], $dir . $arquivo['name'][$i])){
            }else{
            }

            $fotosEditar = $arquivo['name'][$i] . '@' . $fotosEditar;
        }

          if($fotosEditar == ""){
           $fotosEditar = $fotos; 
        }else{
            $fotosEditar = $fotosEditar;
        }

        if($statusEditar != $statusBD){
            $nStatus = $statusEditar;
        }else{
            $nStatus = $statusBD;
        }

        editarImovelTerreno($idEndereco, $idProprietario, $idTelefone, $idImovel, $numeroEditar, $ruaEditar, $bairroEditar, $nomeEditar, $telefoneEditar, $valorEditar, $areaTerrenoEditar, $observacoesEditar, $fotosEditar,$nStatus);
        
    }

    function editarImovelTerreno($idEndereco, $idProprietario, $idTelefone, $codigo, $numeroEditar, $ruaEditar, $bairroEditar, $nomeEditar, $telefoneEditar, $valorEditar,$areaTerrenoEditar, $observacoesEditar, $fotosEditar,$status ){

        include '../config/config.php';


        $qUPDATE = "UPDATE enderecos SET numero = '$numeroEditar', rua = '$ruaEditar', bairro = '$bairroEditar' WHERE idEndereco = '$idEndereco'";
        $ExecutaUpdate = $mysqli->query($qUPDATE);

        $qUPDATEProprietario = "UPDATE dadosproprietario SET nome = '$nomeEditar', idTelefone = '$idTelefone' WHERE idProprietario = '$idProprietario'";
        $ExecutaUpdateP = $mysqli->query($qUPDATEProprietario);

        $qUPDATETelefone  ="UPDATE telefonesproprietario SET Telefone = '$telefoneEditar' WHERE idTelefone = '$idTelefone'";
        $ExecutaUpdateT = $mysqli->query($qUPDATETelefone);


        $qUPDATEGeral  = "UPDATE cadastroterreno SET valor = '$valorEditar', observacoes = '$observacoesEditar', areaTerreno = '$areaTerrenoEditar', fotos = '$fotosEditar' WHERE codigo = '$codigo'";
        $ExecutaUpdateGeral = $mysqli->query($qUPDATEGeral);


        if($ExecutaUpdate && $ExecutaUpdateP && $ExecutaUpdateT && $ExecutaUpdateGeral){
             echo "<script>alert('Imóvel alterado com sucesso');window.location='painel.php'</script>";

        }else{
            echo "<script> alert('Erro ao editar imóvel :( ');window.location='editarImovelTerreno.php?idImovel=$codigo';</script>";

        }
    }

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
		<link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../css/geral.css">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
        <link href="../css/simple-sidebar.css" rel="stylesheet">
        <meta charset="utf-8">
</head>
<body class="azul sem-padding">
	<section>
		<div class="container">
			<div class="row">
				  <div class="col-md-12">
                            <h3 class="text-center txt-espaco">EDITAR TERRENO</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>
                            <div class="container">   
                                <form name="formAddTerreno" method="POST" action="editarImovelTerreno.php?idImovel=<?php echo"$idImovel"?>" enctype="multipart/form-data">   
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Tipo de Negócio</label>
                                                    <select class="form-control diferente-adm" name="negocioTerreno" required="" id="negocio">
                                                        <option class="option-select-padrao" value="venda">Venda</option>
                                                    </select>
                                                </div>
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Imóveis</label>
                                                    <select class="form-control diferente-adm" name="tipoTerreno" required="" id="tipoTerreno">
                                                        <option class="option-select-padrao" value="Terreno">Terreno</option>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Cidade</label>
                                                    <select class="form-control diferente-adm" name="cidadeTerreno" required="" id="cidade">
                                                        <option class="option-select-padrao" value="eunapolis">Eunapolis</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Bairro</label>
                                                    <select class="form-control diferente-adm" name="bairroEditar" id="bairro">
                                                        <option class="option-select-padrao" value="<?php echo"$bairro"?>"><?php echo"$bairro"?></option>
                                                        <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                                        <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                                        <option class="option-select-padrao" value="Centauro">Centauro</option>
                                                        <option class="option-select-padrao" value="Centro">Centro</option>
                                                        <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                                        <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                                        <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                                        <option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
                                                        <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                                        <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                                        <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                                        <option class="option-select-padrao" value="Motor">Motor</option>
                                                        <option class="option-select-padrao" value="Pequi">Pequi</option>
                                                        <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                                        <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                                        <option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
                                                        <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                                        <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                                        <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                                        <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                                        <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                                        <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                                        <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                                        <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                                        <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                                        <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                                        <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Rua</label>
                                                    <input type="text" name="ruaEditar" value="<?php echo"$rua"?>" class="form-control diferente-adm" required="" placeholder="Informe a rua">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Número</label>
                                                    <input type="text" name="numeroEditar" value="<?php echo"$numero"?>" class="form-control diferente-adm" required="" placeholder="Informe o número">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Nome do Proprietário</label>
                                                    <input type="text" name="nomeEditar" value="<?php echo"$nome"?>" class="form-control diferente-adm" required="" placeholder="Informe o nome do proprietário">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Telefone do Proprietário</label>
                                                    <input type="text" name="telefoneEditar" value="<?php echo"$tel"?>" class="form-control diferente-adm" required="" placeholder="Informe o número" id="telefone">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área (m²)</label>
                                                    <input type="text" name="areaTerrenoEditar" value="<?php echo"$area"?>" class="form-control diferente-adm" required="" placeholder="Informe área construída em m²">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Valor R$</label>
                                                    <input type="text" class="form-control diferente-adm dinheiro" value="<?php echo"$valor"?>" name="valorEditar" id="money" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Observações</label>
                                                    <textarea class="form-control diferente-adm mensagem" rows="7" name="observacoesEditar"><?php echo"$observacoes"?></textarea>

                                                </div> 
                                                <label class="col-sm-12 control-label padding-label label-painel">Separe as frases com o uso de ;</label> 
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Status</label>
                                                    <div class="col-md-3">
                                                        <input id="ativo" type="radio" name="statusEditar"  value="ativo" ><label class="control-label padding-label label-painel" for="ativo"> Ativo </label>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input id="passivo" type="radio" name="statusEditar" value="inativo" ><label class="control-label padding-label label-painel" for="passivo"> Inativo </label>
                                                    </div>
                                                </div>  
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12"><label class="col-sm-12 control-label padding-label label-painel">Fotos</label></div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <input type="file" class=" files" name="fotosEditar[]" multiple> <br>
                                                </div>
                                            </div> 
                                        </div>
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <button class="bt-secundario col-md-12 col-sm-12 col-xs-12" name="editarImovelTerreno">ATUALIZAR</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div> 
                        </div>
                        <!-- FIM CADASTRO DE IMÓVEIS TERRENO-->
			</div>
		</div>
	</section>
	<script src="../js/js.js"></script>
            <script src="../js/jquery.js"></script>
            <script src="../js/bootstrap.js"></script>
            <script  src = "../libs/jquery-maskmoney-master/dist/jquery.maskMoney.min.js"  type = "text/javascript " ></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
            <script>

                jQuery("input#telefone")
                .mask("(99) 9999-9999?9")
                .focusout(function (event) {  
                    var target, phone, element;  
                    target = (event.currentTarget) ? event.currentTarget : event.srcElement;  
                    phone = target.value.replace(/\D/g, '');
                    element = $(target);  
                    element.unmask();  
                    if(phone.length > 10) {  
                        element.mask("(99) 99999-999?9");  
                    } else {  
                        element.mask("(99) 99999-9999");  
                    }  
                });
            </script>

</body>
</html>