<?php
	extract($_GET);
	include '../config/config.php';

	$Q =  "DELETE FROM cadastroimovelcomercial WHERE codigo = '$idImovel'";
	$Executaq = $mysqli->query($Q);

	$q1 = "DELETE FROM enderecos WHERE idEndereco = '$idEndereco'";
	$eq1 = $mysqli->query($q1);

	$q2 = "DELETE FROM dadosproprietarios WHERE idProprietario = '$idProprietario'";
	$eq2 = $mysqli->query($q2);

	$q3 = "DELETE FROM telefonesproprietario WHERE idTelefone = '$idTelefone'";
	$eq3 = $mysqli->query($q3);

	echo "<script>alert('Removido com sucesso!');window.location='painel.php'</script>";

?>