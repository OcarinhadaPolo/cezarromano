<?php
	extract($_GET);
	include '../config/config.php';

	$Q =  "DELETE FROM slide WHERE IdSlide = '$idSlide'";
	$Executaq = $mysqli->query($Q);

	

	echo "<script>alert('Removido com sucesso!');window.location='painel.php'</script>";

?>