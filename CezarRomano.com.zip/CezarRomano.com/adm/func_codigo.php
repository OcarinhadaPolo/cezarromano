<?php
	function geraCodigo($tabela,$Tipo){
		include '../config/config.php';
		$q= "SELECT *FROM $tabela WHERE Tipo='$Tipo'";
		$query=$mysqli->query($q);

		$num = mysqli_num_rows($query);

		if($num > 0){
			$codigo;

			while($row=mysqli_fetch_array($query)){
				$codigo=$row['codigo'];
			}
			$codigo++;
			
		}else{
			if($Tipo == "Terreno"){
				$codigo = "T001";
				return $codigo;
			}else if($Tipo == "Sítio"){
				$codigo = "ST001";
			}else if($Tipo == "Fazenda"){
				$codigo = "F001";
			}else if($Tipo == "Sala"){
				$codigo = "S001";
			}else if($Tipo == "Lojas"){
				$codigo = "L001";
			}else if($Tipo == "SalaLiving"){
				$codigo = "SL001";
			}else if($Tipo == "Galpao"){
				$codigo = "G001";
			}else if($Tipo == "Predio"){
				$codigo = "P001";
			}else if($Tipo == "PontoComercial"){
				$codigo = "PC001";
			}else if($Tipo == "AndarComercial"){
				$codigo = "AC001";
			}else if($Tipo == "Sobrado"){
				$codigo = "SB001";
			}else if($Tipo == "Casa"){
				$codigo = "C001";
			}else if($Tipo == "Cobertura"){
				$codigo = "CB001";
			}else if($Tipo == "Kitnet"){
				$codigo = "K001";
			}else if($Tipo == "Apartamento"){
				$codigo = "AP001";
			}
		}

		return $codigo;
	}
 ?>