<?php
	session_start();

	if(!isset($_SESSION['login']) AND !isset($_SESSION['senha'])){
  		header("Location:index.php");
  		exit;   
	}
	include '../config/config.php';
	if(isset($_POST['bt-comercial-adm']) || isset($_POST['bt-residencial-adm']) || isset($_POST['bt-rural-adm']) || isset($_POST['bt-terreno-adm'])){

		extract($_POST);
		//BUSCA COMERCIAL//
			if($bairroComercial != 'padrao' && $valorMaximoComercial == null && $valorMinimoComercial == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if($bairroComercial != 'padrao' && $valorMinimoComercial != null && $valorMaximoComercial == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroComercial != 'padrao' && $valorMinimoComercial == null && $valorMaximoComercial != null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroComercial == 'padrao' && $valorMinimoComercial != null && $valorMaximoComercial == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroComercial == 'padrao' && $valorMinimoComercial == null && $valorMaximoComercial != null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}
		//BUSCA COMERCIAL//

		// BUSCA RESIDENCIAL 
			else if($bairroResidencial != "padrao" && $valorMaximoResidencial == null && $valorMinimoResidencial == null){
			echo "<script>alert('Preencha os campos, valor mínimo e valor máximo 1');window.location='../index.php';</script>";
			}else if($bairroResidencial != "padrao" && $valorMinimoResidencial != null && $valorMaximoResidencial == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo 2');window.location='../index.php';</script>";
			}else if ($bairroResidencial != "padrao" && $valorMinimoResidencial == null && $valorMaximoResidencial != null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo 3');window.location='../index.php';</script>";
			
			}else if ($bairroResidencial == "padrao" && $valorMinimoResidencial != null && $valorMaximoResidencial == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo 4');window.location='../index.php';</script>";
			}else if ($bairroResidencial== "padrao" && $valorMinimoResidencial == null && $valorMaximoResidencial != null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo 5');window.location='../index.php';</script>";
			}

			
		// BUSCA RESIDENCIAL

		//BUSCA RURAL//
			else if($bairroRural != 'padrao' && $valorMaximoRural == null && $valorMinimoRural == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if($bairroRural != 'padrao' && $valorMinimoRural != null && $valorMaximoRural == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroRural != 'padrao' && $valorMinimoRural == null && $valorMaximoRural != null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroRural == 'padrao' && $valorMinimoRural != null && $valorMaximoRural == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroRural == 'padrao' && $valorMinimoRural == null && $valorMaximoRural != null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}
		//BUSCA RURAL//
		//BUSCA TERRENO//
			else if($bairroTerreno != 'padrao' && $valorMaximoTerreno == null && $valorMinimoTerreno == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if($bairroTerreno != 'padrao' && $valorMinimoTerreno != null && $valorMaximoTerreno == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroTerreno != 'padrao' && $valorMinimoTerreno  == null && $valorMaximoTerreno != null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroTerreno == 'padrao' && $valorMinimoTerreno != null && $valorMaximoTerreno == null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}else if ($bairroTerreno == 'padrao' && $valorMinimoTerreno == null && $valorMaximoTerreno != null){
				echo "<script>alert('Preencha os campos, valor mínimo e valor máximo');window.location='../index.php';</script>";
			}
		//BUSCA TERRENO//
		?>






<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<meta charset="utf-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    	<meta name="description" content="">
    	<meta name="author" content="">
		<link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../css/geral.css">
		<link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
	</head>
	<body>
		<nav class="navbar navbar-default menu navbar-expand-lg navbar-dark bg-dark navbar-fixed-top" id="mainNav">
      			<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				        	<span class="sr-only">Toggle navigation</span>
				        	<span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
		      			</button>
						<a class="navbar-brand js-scroll-trigge" href="#page-top"><img src="../img/logo.png"  class="img-responsive logo" alt="Cezar-Romano" width="160"></a>
					</div>
					<div class="collapse navbar-collapse" id="navbarResponsive">
						<ul class="nav navbar-nav ml-auto navbar-right">
							<li class="nav-item text-center item-menu">
								<a class="nav-link itens js-scroll-trigger scrollSuave" href="../index.php">Home</a>
							</li>
						</ul>
					</div>
				</div>
    		</nav>
    		
    		<?php
    			switch ($tipoTop) {
					case 'comercial':
			?>
					<section class="section-buscados">
			   			<div class="container">
			    			<h1 class="text-center bold branco">LISTA DE IMÓVEIS</h1>
			    			<div class="row">
			    				<div class="col-md-12 margin-bottom">
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center"><?php echo "$negocioComercial"; ?></div>
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center"><?php echo "$tipoComercial"; ?></div>
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center"><?php echo "R$ $valorMinimoComercial - R$ $valorMaximoComercial"; ?></div>
				    			</div>
			<?php

					if($tipoComercial == 'padrao' && $bairroComercial == 'padrao' && $valorMaximoComercial == null & $valorMinimoComercial == null){
			
				    				$qListaComercial = $mysqli->query("SELECT * FROM cadastroimovelcomercial INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroimovelcomercial.idEndereco = enderecos.idEndereco AND cadastroimovelcomercial.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone ");

				    				if(mysqli_num_rows($qListaComercial) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}


										while($row1 = mysqli_fetch_array($qListaComercial)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/comercial/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeComercial"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>

				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}

				    				?>
				    			
	    				<?php

    				}if($tipoComercial != null && $bairroComercial != null && $valorMinimoComercial != null && $valorMaximoComercial != null){

   
				    				$qListaComercial = $mysqli->query("SELECT * FROM cadastroimovelcomercial INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroimovelcomercial.idEndereco = enderecos.idEndereco AND cadastroimovelcomercial.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone WHERE tipo = '$tipoComercial' AND bairro = '$bairroComercial' AND valor <= $valorMaximoComercial AND valor >= $valorMinimoComercial ");

				    				if(mysqli_num_rows($qListaComercial) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaComercial)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/comercial/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeComercial"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>
				    	

				    				<?php
				    						}
				    					}if($tipoComercial == 'padrao' && $bairroComercial != 'padrao' && $valorMinimoComercial != null && $valorMaximoComercial != null){
    					?>


				    				<?php 
				    				$qListaComercial = $mysqli->query("SELECT * FROM cadastroimovelcomercial INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroimovelcomercial.idEndereco = enderecos.idEndereco AND cadastroimovelcomercial.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone WHERE bairro = '$bairroComercial' AND valor >= $valorMinimoComercial AND valor <= $valorMaximoComercial ");

				    				if(mysqli_num_rows($qListaComercial) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaComercial)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/comercial/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeComercial"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    		}		
    					}

    					?>
    					</div>
			    	</div>
    		</section>
    					<?php
    				
							break;

							case 'residencial':

							?>
							<section class="section-buscados">
			    			<div class="container">
			    				<h1 class="text-center bold branco">LISTA DE IMÓVEIS</h1>
			    				<div class="row">
			    					<div class="col-md-12 margin-bottom">
				    					<div class="col-md-1"></div>
				    					<div class="col-md-3 item-buscado text-center"><?php echo"$negocioResidencial" ; ?></div>
				    					<div class="col-md-1"></div>
				    					<div class="col-md-3 item-buscado text-center"><?php echo "$tipoResidencial"; ?></div>
				    					<div class="col-md-1"></div>
				    					<div class="col-md-3 item-buscado text-center"><?php echo "R$ $valorMinimoResidencial - R$ $valorMaximoResidencial"; ?></div>
				    				</div>
							<?php

									if($negocioResidencial== 'padrao' && $tipoResidencial == 'padrao' && $bairroResidencial == 'padrao' && $valorMaximoResidencial == null && $valorMinimoResidencial == null && $Nquartos!=null && $Nbanheiros!=null && $Nsuites != null){

										$qListaResidencial = $mysqli->query("SELECT * FROM cadastroimovelresidencial INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroimovelresidencial.idEndereco = enderecos.idEndereco AND cadastroimovelresidencial.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone ");

										if(mysqli_num_rows($qListaResidencial) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaResidencial)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/residencial/'.$img1;
							?>
											<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeResidencial"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>


				    				<?php

				    						}
				    					} if($tipoResidencial != 'padrao' && $bairroResidencial != 'padrao' && $valorMinimoResidencial != null && $valorMaximoResidencial != null && $Nquartos != null && $Nbanheiros != null && $Nsuites!= null){ 

				    						$qListaResidencial = $mysqli->query("SELECT * FROM cadastroimovelresidencial INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroimovelresidencial.idEndereco = enderecos.idEndereco AND cadastroimovelresidencial.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone WHERE tipo = '$tipoResidencial' AND bairro = '$bairroResidencial' AND valor <= $valorMaximoResidencial AND valor >= $valorMinimoResidencial AND numeroQuartos = '$Nquartos' AND numeroBanheiros = '$Nbanheiros' AND numeroSuites = '$Nsuites' ");

				    						if(mysqli_num_rows($qListaResidencial) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaResidencial)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/residencial/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeResidencial"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}

				    					}if($tipoResidencial == 'padrao' && $bairroResidencial != 'padrao' && $valorMinimoResidencial != null && $valorMaximoResidencial != null && $valorMinimoResidencial == null && $Nquartos!=null && $Nbanheiros!=null && $Nsuites != null){

				    						$qListaResidencial = $mysqli->query("SELECT * FROM cadastroimovelresidencial INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroimovelresidencial.idEndereco = enderecos.idEndereco AND cadastroimovelresidencial.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone WHERE bairro = '$bairroResidencial' AND valor >= $valorMinimoResidencial AND valor <= $valorMaximoResidencial");

				    						if(mysqli_num_rows($qListaResidencial) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaResidencial)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/residencial/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeResidencial"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}
				    					}

				    				?>
				    				?>
							</div>
			    	</div>
    		</section>
							<?php
							break;
						// CASO RURAL //
							case 'rural':

						?>
						<section class="section-buscados">
			   			<div class="container">
			    			<h1 class="text-center bold branco">LISTA DE IMÓVEIS</h1>
			    			<div class="row">
			    				<div class="col-md-12 margin-bottom">
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center"><?php echo "$negocioRural"; ?></div>
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center"><?php echo "$tipoRural"; ?></div>
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center"><?php echo "R$ $valorMinimoRural - R$ $valorMaximoRural"; ?></div>
				    			</div>
						<?php
								if($tipoRural == 'padrao' && $bairroRural == 'padrao' && $valorMaximoRural == null & $valorMinimoRural == null){
			
				    				$qListaRural = $mysqli->query("SELECT * FROM cadastrorural INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastrorural.idEndereco = enderecos.idEndereco AND cadastrorural.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone ");

				    				if(mysqli_num_rows($qListaRural) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaRural)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/rural/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeRural"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}

    				}if($tipoRural != 'padrao' && $bairroRural != 'padrao' && $valorMinimoRural != null && $valorMaximoRural != null){


				    				$qListaRural = $mysqli->query("SELECT * FROM cadastrorural INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastrorural.idEndereco = enderecos.idEndereco AND cadastrorural.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone WHERE tipo = '$tipoRural' AND bairro = '$bairroRural' AND valor <= $valorMaximoRural AND valor >= $valorMinimoRural ");

				    				if(mysqli_num_rows($qListaRural) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaRural)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/rural/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeRural"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}
				    					}if($tipoRural == 'padrao' && $bairroRural != 'padrao' && $valorMinimoRural != null && $valorMaximoRural != null){	

    					?>


				    				<?php 
				    				$qListaRural = $mysqli->query("SELECT * FROM cadastrorural INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastrorural.idEndereco = enderecos.idEndereco AND cadastrorural.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone WHERE bairro = '$bairroRural' AND valor >= $valorMinimoRural AND valor <= $valorMaximoRural ");

				    				if(mysqli_num_rows($qListaRural) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaRural)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url ='../img/imoveis/rural/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeRural"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}

				    				?>

				    				?>
				    			
    					<?php
    				}
    				?>
    				</div>
			    	</div>
    		</section>
    				<?php
							break;
						//FIM CASO RURAL//
						// CASO TERRENO//
							case 'terreno':
								?>
						<section class="section-buscados">
			   			<div class="container">
			    			<h1 class="text-center bold branco">LISTA DE IMÓVEIS</h1>
			    			<div class="row">
			    				<div class="col-md-12 margin-bottom">
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center">VENDA</div>
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center">TERRENOS</div>
							    	<div class="col-md-1"></div>
							    	<div class="col-md-3 item-buscado text-center"><?php echo "R$ $valorMinimoTerreno - R$ $valorMaximoTerreno"; ?></div>
				    			</div>
						<?php
								if($bairroTerreno == 'padrao' && $valorMaximoTerreno == null & $valorMinimoTerreno == null){
			
				    				$qListaTerreno = $mysqli->query("SELECT * FROM cadastroterreno INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroterreno.idEndereco = enderecos.idEndereco AND cadastroterreno.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone ");

				    				if(mysqli_num_rows($qListaTerreno) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaTerreno)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/terreno/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeTerreno"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}

    				}if($bairroTerreno != null && $valorMinimoTerreno != null && $valorMaximoTerreno != null){


				    				$qListaTerreno = $mysqli->query("SELECT * FROM cadastroterreno INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroterreno.idEndereco = enderecos.idEndereco AND cadastroterreno.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone WHERE bairro = '$bairroTerreno' AND valor <= $valorMaximoTerreno AND valor >= $valorMinimoTerreno ");

				    				if(mysqli_num_rows($qListaTerreno) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaTerreno)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url ='../img/imoveis/terreno/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeRural"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}
				    					}if($tipoRural == 'padrao' && $bairroRural != null && $valorMinimoRural != null && $valorMaximoRural != null){

    					?>


				    				<?php 
				    				$qListaRural = $mysqli->query("SELECT * FROM cadastrorural INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastrorural.idEndereco = enderecos.idEndereco AND cadastrorural.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone WHERE bairro = '$bairroRural' AND valor >= $valorMinimoRural AND valor <= $valorMaximoRural ");

				    				if(mysqli_num_rows($qListaTerreno) <= 0){
				    					echo "<script>alert('Nenhum imóvel encontrado, tente buscar passando novos parâmetros');window.location='../index.php';</script>";
				    				}

										while($row1 = mysqli_fetch_array($qListaRural)){
											$codigo = $row1['codigo'];
											$valor = $row1['valor'];
											$bairro = $row1['bairro'];

											$imagems = $row1['fotos'];
											$newImage = explode('@', $imagems);
											$img1 = $newImage[0];

											$url = '../img/imoveis/terreno/'.$img1;
						
									?>
				    				<div class="col-md-12 separador">
				    					<div class="container">
				    						<label for="inputPassword3" class="col-sm-12 control-label padding-label tags">

				    						<div class="col-md-12">

				    							<?php echo"<a href='ImovelEspecificoADM.php?idImovel=$codigo'><img src='$url' class = 	'img-responsive  col-md-3' /> </a>"?>
				    							<div class="col-md-9">
				    								<span class="preco col-md-12"> R$ <?php echo "$valor"; ?></span>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Cidade <br> <span class="tags-extra" style="text-transform: capitalize;"><?php echo "$cidadeRural"; ?></span>
				    								</label>

				    								<label for="inputPassword3" class="col-sm-6 control-label padding-label tags">
				    									Bairro <br> <span class="tags-extra"><?php echo "$bairro"; ?></span>
				    								</label>
				    							</div>
				    						</div>
				    					</div>
				    				</div>

				    				<?php
				    						}

				    				?>

				    				?>
				    			
    					<?php
    				}
    				?>
    				</div>
			    </div>
    		</section>
    				<?php
    					//FIM CASO TERRENO//
							break;
			
			
						}
						?>
    					
    		<!--RODAPE TOP-->
	    		<section class="rodape">
					<label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
					<div class="container">
			    			<div class="col-md-12">
			                    <center><ul class="social-network social-circle">
			                  
			                        <li><a href="#" class="icoFacebook r-social" title="Facebook"><i class="fa fa-facebook"></i></a></li>
			                        <li><a href="#" class="icoGoogle r-social" title="Google +"><i class="fa fa-google-plus"></i></a></li>
			                        <li><a href="#" class="icoPhone r-social" title="Telefone"><i class="fa fa-whatsapp"></i></a></li>
			                    </ul></center>				
							</div>
							<div class="col-md-12">
								<h6 class="text-left branco col-md-6">Telefone: (73) Xxxxx-xxxx</h6>
								<h6 class="text-right branco col-md-6">© Copyright - Todos os direitos reservados</h6>
							</div>
					</div>
				</section>
			<!--FIM RODAPE TOP-->
		<script src="../js/js.js"></script>
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.js"></script>
		<script src="../js/scrolling-nav.js"></script>
    	<script src="../js/bootstrap.bundle.min.js"></script>

    	<!-- Plugin JavaScript -->
    	<script src="../js/jquery.easing.min.js"></script>
    	<script type="text/javascript">

			$(window).scroll(function () {
          		var topWindow = $(this).scrollTop();
          		if (topWindow > 70 ) {
            		$('nav').addClass('nav-cor');
            		$('.logo').addClass('nav-logo');
			 } else{
            	$('nav').removeClass('nav-cor');
            	$('.logo').removeClass('nav-logo');
 			}

  			});
		</script>
	</body>
</html>
<?php
	}else{
		echo "<script>alert('Nenhum parâmetro de busca encontrado :/ ');window.location='../index.php';</script>";
	}

?>