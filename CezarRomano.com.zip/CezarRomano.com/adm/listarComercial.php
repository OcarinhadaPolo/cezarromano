<?php
    include '../config/config.php';
    session_start();
    $pagina = (isset($_GET["pagina"]))? (int)$_GET["pagina"] : 0;



    

?>
<!DOCTYPE html>
<html>
    <head>
    <title>Listar Imóveis Comercial</title>
        <link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../css/geral.css">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
        <link href="../css/simple-sidebar.css" rel="stylesheet">
        <meta charset="utf-8">
    </head>
<body>
    <!--EDITA IMOVEL COMERCIAL-->
                        <div class="col-md-12" id="ListaImovelComercial">
                            <span onclick="remostraLista();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">LISTAR  IMÓVEIS COMERCIAL</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>                          
                                
                                
                                <?php 
                                    

                                    $itens_por_pagina = 10;

                                    

                                    $qListaComercial = "SELECT * FROM cadastroimovelcomercial INNER JOIN enderecos INNER JOIN dadosproprietario INNER JOIN telefonesproprietario ON cadastroimovelcomercial.idEndereco = enderecos.idEndereco AND cadastroimovelcomercial.idProprietario = dadosproprietario.idProprietario AND dadosproprietario.idTelefone = telefonesproprietario.idTelefone LIMIT $pagina, $itens_por_pagina";
                                    $executaListaComercial = $mysqli->query($qListaComercial);

            
                                    $num = mysqli_num_rows($executaListaComercial);
                                    $num_total = $mysqli->query("SELECT * FROM cadastroimovelcomercial")->num_rows;
                                    $num_paginas = ceil($num_total / $itens_por_pagina);


                                      
                                    
                                    ?>
                                        <table class="table table-condensed ">
                                        <thead>
                                            <tr>
                                                <th><span class="badge">Código</span></th>
                                                <th>Negócio</th>
                                                <th>Tipo</th>
                                                <th>Valor</th>
                                                <th>Endereço</th>
                                                <th>Dados do Proprietário</th>
                                                <th>Área Construída</th>
                                                <th>Área do Terreno</th>
                                                <th>Observações</th>
                                                <th>Galeria</th>
                                                
                                               
                                             </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $i = 1;
                                                while($row = mysqli_fetch_array($executaListaComercial)){
                                                    
                                                    $Codigo = $row['codigo'];
                                                    $Negocio = $row['negocio'];
                                                    $Tipo  =  $row['tipo'];
                                                    $Valor = $row['valor'];
                                                    $Rua = $row['rua'];
                                                    $Numero = $row['numero'];
                                                    $Bairro = $row['bairro'];
                                                    $Nome = $row['nome'];
                                                    $AreaConstruida = $row['areaConstruida'];
                                                    $AreaTerreno = $row['areaTerreno'];
                                                    $Observacoes = $row['observacoes'];
                                                    $fotos = $row['fotos'];

                                                    $foto = explode('@', $fotos);
                                                    $cont = count($foto);
                                                    //echo "$cont";
                                                    $foto = $foto[0];

                                                    $caminho = "../img/imoveis/comercial/". $foto;
                                                    $Telefone = $row['Telefone'];

                                                    $classe = "bs-example-modal-lg" . $i;
                                                    $target = ".bs-example-modal-lg" . $i;
                                                   
                                            ?>
                                            <tr>
                                                <td><?php echo "$Codigo" ?></td>
                                                <td><?php echo "$Negocio"; ?></td>
                                                <td><?php echo "$Tipo"; ?></td>
                                                <td><?php echo "$Valor"; ?></td>
                                                <td><?php echo "$Rua, $Numero, $Bairro - Eunápolis-BA"?></td>
                                                <td><?php echo "$Nome, $Telefone";?></td>
                                                <td><?php echo "$AreaConstruida"; ?></td>
                                                <td><?php echo "$AreaTerreno"; ?></td>
                                                <td><?php echo "$Observacoes"; ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="<?php echo"$target"; ?>">Galeria</button>

                                                </td>
                                            </tr>
                                            <div class="modal fade <?php echo "$classe"; ?>" tabindex="1" role="dialog" aria-labelledby="myLargeModalLabel">
                                              <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <br>
                                                    <h3 class="text-center uppercase">Galeria de Imagens</h3> <br>
                                                    <center><img src="<?php echo "$caminho"; ?>" class="img-responsive borda " /></center>
                                                  
                                                </div>
                                              </div>
                                            </div>
                                        <?php $i++; } ?>
                                        </tbody>
                                    </table>
                                    <nav aria-label="Page navigation">
                                          <ul class="pagination">
                                            <li>
                                              <a href="listarComercial.php?pagina=0" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                              </a>
                                            </li>
                                            <?php 
                                                for($i =0; $i < $num_paginas;$i++){
                                                    $estilo = "";
                                                    if($pagina == $i){
                                                        $estilo = "class=\"active\"";
                                                    }
                                            ?>
                                            <li <?php echo $estilo ?> ><a href="listarComercial.php?pagina=<?php echo $i ?>"><?php echo $i+1; ?></a></li>
                                            <?php }?>
                                            <li>
                                              <a href="listarComercial.php?pagina=<?php echo $num_paginas-1; ?>" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                              </a>
                                            </li>
                                          </ul>
                                    </nav>
                                    <?php
                                        
                                    ?>
                                
                        </div>
                        <!--FIM EDITAR IMOVEL COMERCIAL-->
                        <script src="../js/js.js"></script>
            <script src="../js/jquery.js"></script>
            <script src="../js/bootstrap.js"></script>
            <script  src = "../libs/jquery-maskmoney-master/dist/jquery.maskMoney.min.js"  type = "text/javascript " ></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
</body>
</html>