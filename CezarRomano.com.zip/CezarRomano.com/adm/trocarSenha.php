<?php
	session_start();
	if(!isset($_SESSION['login']) AND !isset($_SESSION['senha'])){
  		header("Location:index.php");
  		exit;   
	}

	if(isset($_POST['trocar'])){
		extract($_POST);
		include '../config/config.php';

		$q = $mysqli->query("SELECT * FROM administrador");
		while ($row = mysqli_fetch_array($q)) {
			$senha = $row['senha'];
			$id = $row['idAdm'];
		}

		$senhaAntiga = hash('md5', $senhaAntiga);
		$nSenha = hash('md5', $nSenha);
	

		if($senhaAntiga == $senha){
			$muda = $mysqli->query("UPDATE administrador SET senha = '$nSenha' WHERE idAdm = $id");
			session_destroy();
			echo "<script>alert('Senha Alterada com sucesso');window.location='index.php';</script>";


		}else{
			echo "<script>alert('Senha não confere');</script>";
		}
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Trocar Senha</title>
		<link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../css/geral.css">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
        <link href="../css/simple-sidebar.css" rel="stylesheet">
        <meta charset="utf-8">
	</head>
	<body>
		<section>
			<div class="row">
				<div class="container">
					<div class="col-md-12">
						<form method="POST" action="trocarSenha.php">
							<div class="form-group">
                                <div class="col-md-12">
                                	<label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Senha Atual</label>
                                	<input type="password" name="senhaAntiga" class="form-control diferente-adm" required="" placeholder="Informe a senha antiga">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12">
                                	<label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Nova Senha</label>
                                	<input type="password" name="nSenha" class="form-control diferente-adm" required="" placeholder="Informe a novaSenha">
                                </div>
                            </div>
                             <div class="form-group">
                                    <div class="col-md-12">
                                        <button class="bt-secundario col-md-12 col-sm-12 col-xs-12" name="trocar">ALTERAR SENHA</button>
                                    </div>
                             </div>
                            
						</form>
					</div>
				</div>
			</div>
		</section>
		<script src="../js/js.js"></script>
        <script src="../js/jquery.js"></script>
        <script src="../js/bootstrap.js"></script>
        <script  src = "../libs/jquery-maskmoney-master/dist/jquery.maskMoney.min.js"  type = "text/javascript " ></script>
	</body>
</html>