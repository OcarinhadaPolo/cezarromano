<?php
$senhaN;
session_start();

include '../config/config.php';
include 'func_codigo.php';

    // REGISTRO COMERCIAL BANCO DE DADOS//

if(!isset($_SESSION['login']) AND !isset($_SESSION['senha'])){
  header("Location:index.php");
  exit;   
}

if(isset($_POST['enviarSobre'])){
    extract($_GET);
    extract($_POST);

    $textoSobre= preg_replace("/(\\r)?\\n/i", "<br/>", $textoSobre);

    $qSobre = "UPDATE  sobre SET descricao = '$textoSobre' WHERE idSobre = '$idSobre'";
    $qqSobre = $mysqli->query($qSobre);

    if($qqSobre){
        echo "<script>alert('Texto atualizado com sucesso');</script>";
    }else{
        echo "<script>alert('Erro ao atualizar :/ ');</script>";       
    }
}
if(isset($_POST['enviarSlide'])){
    extract($_GET);
    extract($_POST);
        $dir = '../img/img-slider' . DIRECTORY_SEPARATOR;
        $arquivo = isset($_FILES['foto']) ? $_FILES['foto'] : FALSE;



    $fotosEditar = "";

        for ($i = 0; $i < count($arquivo['size']); $i++){
            if (move_uploaded_file($arquivo['tmp_name'][$i], $dir . $arquivo['name'][$i])){
            }else{
            }

            $fotosEditar = $arquivo['name'][$i] . '@' . $fotosEditar;
        }

          if($fotosEditar == ""){
           $fotosEditar = $caminho; 
        }else{
            $fotosEditar = $fotosEditar;
        }

        $qSlide = "UPDATE slide SET caminho = '$fotosEditar' WHERE idSlide = '$idSlide' ";
        $qqSlide = $mysqli->query($qSlide);

        if($qqSlide){
            echo "<script>alert('Banner atualizado com sucesso');</script>";
        }else{
            echo "<script>alert('Erro ao atualizar :/ ');</script>";       
        }
}

if(isset($_POST['cadastrarComercial'])){
    $caminhosTotal = "";
    $idProprietario;
    $idTelefone;
    $idEndereco;
    $dir = '../img/imoveis/comercial' . DIRECTORY_SEPARATOR;
    $arquivo = isset($_FILES['foto']) ? $_FILES['foto'] : FALSE;

    for ($i = 0; $i < count($arquivo['size']); $i++){
        if (move_uploaded_file($arquivo['tmp_name'][$i], $dir . $arquivo['name'][$i])){
            
        }else{
            echo "<script>alert('Erro ao enviar imagem');</script>";

        }

        $caminhosTotal = $arquivo['name'][$i] . '@' . $caminhosTotal;
    }
    extract($_POST);

    $qInsereEndereco = "INSERT INTO enderecos VALUES ('','$numeroComercial','$ruaComercial','$bairroComercial','1')";
    $InsereEndereco = $mysqli->query($qInsereEndereco);

    $pegaIdEndereco = "SELECT * FROM enderecos WHERE numero  = '$numeroComercial' AND rua = '$ruaComercial'";
    $pegadoEndereco = $mysqli->query($pegaIdEndereco);

    while($row = mysqli_fetch_array($pegadoEndereco)){
        $idEndereco = $row['idEndereco'];
    }


    $qInsereTelefone = "INSERT INTO telefonesproprietario VALUES ('','$telefoneProprietarioComercial')";
    $InsereTelefone = $mysqli->query($qInsereTelefone);

    $pegaIdTelefone = "SELECT * FROM telefonesproprietario WHERE Telefone = '$telefoneProprietarioComercial'";
    $PegadoTelefone = $mysqli->query($pegaIdTelefone);

    while($rows = mysqli_fetch_array($PegadoTelefone)){
        $idTelefone = $rows['idTelefone'];
    }
    $qIndereDadosProprietario = "INSERT INTO dadosproprietario VALUES ('','$nomeProprietarioComercial','$idTelefone')";
    $InsereDadosProprietario = $mysqli->query($qIndereDadosProprietario);

    $pegaIdDadosProprietario = "SELECT * FROM dadosproprietario WHERE nome = '$nomeProprietarioComercial' AND idTelefone = '$idTelefone'";
    $PegadoIdDadosProprietario = $mysqli->query($pegaIdDadosProprietario);

    while($rowss = mysqli_fetch_array($PegadoIdDadosProprietario)){
        $idProprietario = $rowss['idProprietario'];
    }
    $tabela = "cadastroimovelcomercial";
    $codigo = geraCodigo('cadastroimovelcomercial', $tipoComercial);
    $insereImovelComercial = "INSERT INTO cadastroimovelcomercial VALUES ('$codigo','$negocioComercial','$tipoComercial','$valorComercial','$idEndereco','$idProprietario', '$observacoesComercial','$areaConstruidaComercial','$areaTerrenoComercial','$caminhosTotal','','$statusComercial')";

    $EnviaComercial = $mysqli->query($insereImovelComercial);

    if($EnviaComercial){
        echo "<script>alert('Imóvel Cadastrado Com Sucesso')</script>";
    }
}
    //FIM REGISTRO COMERCIAL BANCO DE DADOS//
//--- CADASTRO RURAL-->
if(isset($_POST['cadastrarRural'])){
    $caminhosTotal = "";
    $idProprietario;
    $idTelefone;
    $idEndereco;
    $dir = '../img/imoveis/rural' . DIRECTORY_SEPARATOR;
    $arquivo = isset($_FILES['foto']) ? $_FILES['foto'] : FALSE;

    for ($i = 0; $i < count($arquivo['size']); $i++){
        if (move_uploaded_file($arquivo['tmp_name'][$i], $dir . $arquivo['name'][$i])){
            
        }else{
            echo "<script>alert('Erro ao enviar imagem');</script>";

        }

        $caminhosTotal = $arquivo['name'][$i] . '@' . $caminhosTotal;
    }
    extract($_POST);

    $qInsereEndereco = "INSERT INTO enderecos VALUES ('','$numeroRural','$ruaRural','$bairroRural','1')";
    $InsereEndereco = $mysqli->query($qInsereEndereco);

    $pegaIdEndereco = "SELECT * FROM enderecos WHERE numero  = '$numeroRural' AND rua = '$ruaRural'";
    $pegadoEndereco = $mysqli->query($pegaIdEndereco);

    while($row = mysqli_fetch_array($pegadoEndereco)){
        $idEndereco = $row['idEndereco'];
    }


    $qInsereTelefone = "INSERT INTO telefonesproprietario VALUES ('','$telefoneProprietarioRural')";
    $InsereTelefone = $mysqli->query($qInsereTelefone);

    $pegaIdTelefone = "SELECT * FROM telefonesproprietario WHERE Telefone = '$telefoneProprietarioRural'";
    $PegadoTelefone = $mysqli->query($pegaIdTelefone);

    while($rows = mysqli_fetch_array($PegadoTelefone)){
        $idTelefone = $rows['idTelefone'];
    }
    $qIndereDadosProprietario = "INSERT INTO dadosproprietario VALUES ('','$nomeProprietarioRural','$idTelefone')";
    $InsereDadosProprietario = $mysqli->query($qIndereDadosProprietario);

    $pegaIdDadosProprietario = "SELECT * FROM dadosproprietario WHERE nome = '$nomeProprietarioRural' AND idTelefone = '$idTelefone'";
    $PegadoIdDadosProprietario = $mysqli->query($pegaIdDadosProprietario);

    while($rowss = mysqli_fetch_array($PegadoIdDadosProprietario)){
        $idProprietario = $rowss['idProprietario'];
    }
    $tabela = "cadastrorural";
    $codigo = geraCodigo('cadastrorural', $tipoRural);
    $insereRural = "INSERT INTO cadastrorural VALUES ('$codigo','$negocioRural','$tipoRural','$valorRural','$idEndereco','$idProprietario','$areaConstruidaHRural','$areaTerrenoHRural','$areaConstruidaARural','$areaTerrenoARural','$observacoesRural','$caminhosTotal','','$statusRural')";

    $EnviaRural = $mysqli->query($insereRural);

    if($EnviaRural){
        echo "<script>alert('Imóvel Cadastrado Com Sucesso')</script>";
    }
}
//--- FIM CADASTRO RURAL--//

    //O QUE VENIS FEZ//

    //REGISTRO RESIDENCIAL BANCO DE DADOS//

if(isset($_POST['cadastrarResidencial'])){
    $caminhosTotal = "";
    $idProprietario;
    $idTelefone;
    $idEndereco;
    $dir = '../img/imoveis/residencial' . DIRECTORY_SEPARATOR;
    $arquivo = isset($_FILES['foto']) ? $_FILES['foto'] : FALSE;

    for ($i = 0; $i < count($arquivo['size']); $i++){
        if (move_uploaded_file($arquivo['tmp_name'][$i], $dir . $arquivo['name'][$i])){
           
        }else{
            echo "<script>alert('Erro ao enviar imagem');</script>";

        }

        $caminhosTotal = $arquivo['name'][$i] . '@' . $caminhosTotal;
    }
    extract($_POST);

    $qInsereEndereco = "INSERT INTO enderecos VALUES ('','$numeroResidencial','$ruaResidencial','$bairroResidencial','1')";
    $InsereEndereco = $mysqli->query($qInsereEndereco);

    $pegaIdEndereco = "SELECT * FROM enderecos WHERE numero  = '$numeroResidencial' AND rua = '$ruaResidencial'";
    $pegadoEndereco = $mysqli->query($pegaIdEndereco);

    while($row = mysqli_fetch_array($pegadoEndereco)){
        $idEndereco = $row['idEndereco'];
    }


    $qInsereTelefone = "INSERT INTO telefonesproprietario VALUES ('','$telefoneProprietarioResidencial')";
    $InsereTelefone = $mysqli->query($qInsereTelefone);

    $pegaIdTelefone = "SELECT * FROM telefonesproprietario WHERE Telefone = '$telefoneProprietarioResidencial'";
    $PegadoTelefone = $mysqli->query($pegaIdTelefone);

    while($rows = mysqli_fetch_array($PegadoTelefone)){
        $idTelefone = $rows['idTelefone'];
    }
    $qIndereDadosProprietario = "INSERT INTO dadosproprietario VALUES ('','$nomeProprietarioResidencial','$idTelefone')";
    $InsereDadosProprietario = $mysqli->query($qIndereDadosProprietario);

    $pegaIdDadosProprietario = "SELECT * FROM dadosproprietario WHERE nome = '$nomeProprietarioResidencial' AND idTelefone = '$idTelefone'";
    $PegadoIdDadosProprietario = $mysqli->query($pegaIdDadosProprietario);

    while($rowss = mysqli_fetch_array($PegadoIdDadosProprietario)){
        $idProprietario = $rowss['idProprietario'];
    }
    $tabela = "cadastroimovelresidencial";
    $codigo = geraCodigo('cadastroimovelresidencial', $tipoResidencial);
    $insereImovelResidencial = "INSERT INTO cadastroimovelresidencial VALUES ('$codigo','$negocioResidencial','$tipoResidencial','$valorResidencial','$idEndereco','$idProprietario','$numeroQuartos','$numeroBanheiros','numeroSuites' ,'$observacoesResidencial','$areaConstruidaResidencial','$areaTerrenoResidencial','$caminhosTotal','','$statusResidencial')";

    $EnviaResidencial = $mysqli->query($insereImovelResidencial);

    if($EnviaResidencial){
        echo "<script>alert('Imóvel Cadastrado Com Sucesso')</script>";
    }
}
//FIM REGISTRO RESIDENCIAL BANCO DE DADOS//

 //REGISTRO TERRENO BANCO DE DADOS//

if(isset($_POST['cadastrarTerreno'])){
    $caminhosTotal = "";
    $idProprietario;
    $idTelefone;
    $idEndereco;
    $dir = '../img/imoveis/terreno' . DIRECTORY_SEPARATOR;
    $arquivo = isset($_FILES['foto']) ? $_FILES['foto'] : FALSE;

    for ($i = 0; $i < count($arquivo['size']); $i++){
        if (move_uploaded_file($arquivo['tmp_name'][$i], $dir . $arquivo['name'][$i])){
           
        }else{
            echo "<script>alert('Erro ao enviar imagem');</script>";
        }

        $caminhosTotal = $arquivo['name'][$i] . '@' . $caminhosTotal;
    }
    extract($_POST);

    $qInsereEndereco = "INSERT INTO enderecos VALUES ('','$numeroTerreno','$ruaTerreno','$bairroTerreno','1')";
    $InsereEndereco = $mysqli->query($qInsereEndereco);

    $pegaIdEndereco = "SELECT * FROM enderecos WHERE numero  = '$numeroTerreno' AND rua = '$ruaTerreno'";
    $pegadoEndereco = $mysqli->query($pegaIdEndereco);

    while($row = mysqli_fetch_array($pegadoEndereco)){
        $idEndereco = $row['idEndereco'];
    }


    $qInsereTelefone = "INSERT INTO telefonesproprietario VALUES ('','$telefoneProprietarioTerreno')";
    $InsereTelefone = $mysqli->query($qInsereTelefone);

    $pegaIdTelefone = "SELECT * FROM telefonesproprietario WHERE Telefone = '$telefoneProprietarioTerreno'";
    $PegadoTelefone = $mysqli->query($pegaIdTelefone);

    while($rows = mysqli_fetch_array($PegadoTelefone)){
        $idTelefone = $rows['idTelefone'];
    }
    $qIndereDadosProprietario = "INSERT INTO dadosproprietario VALUES ('','$nomeProprietarioTerreno','$idTelefone')";
    $InsereDadosProprietario = $mysqli->query($qIndereDadosProprietario);

    $pegaIdDadosProprietario = "SELECT * FROM dadosproprietario WHERE nome = '$nomeProprietarioTerreno' AND idTelefone = '$idTelefone'";
    $PegadoIdDadosProprietario = $mysqli->query($pegaIdDadosProprietario);

    while($rowss = mysqli_fetch_array($PegadoIdDadosProprietario)){
        $idProprietario = $rowss['idProprietario'];
    }
    $tabela = "cadastroterreno";
    $codigo = geraCodigo('cadastroterreno', $tipoTerreno);
    $insereTerreno = "INSERT INTO cadastroterreno VALUES ('$codigo','$negocioTerreno','$tipoTerreno','$areaTerreno','$valorTerreno','$idEndereco','$idProprietario','$observacoesTerreno','$caminhosTotal','','$statusTerreno')";

    $EnviaTerreno = $mysqli->query($insereTerreno);

    if($EnviaTerreno){
        echo "<script>alert('Imóvel Cadastrado Com Sucesso')</script>";
    }
}
//FIM REGISTRO TERRENO BANCO DE DADOS//
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Painel Administrativo</title>
        <link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../css/geral.css">
        <link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
        <link href="../css/simple-sidebar.css" rel="stylesheet">
        <meta charset="utf-8">
    </head>
    <body class="azul sem-padding" onload="aparece();">
        <section class="aparecer topo-azul navbar-fixed-top">
            <div class="row">
                <div class="col-md-12">
                    <h6 class="text-left col-md-6 col-sm-6 col-xs-6">PAINEL ADMINISTRATIVO</h6>
                    <h6 class="text-right col-md-6 col-sm-6 col-xs-6"><a href="logout.php">Sair</a></h6>
                </div>
            </div>
        </section>
        <section class="aparecer">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div id="wrapper">
                            <nav id="spy">
                            <!-- Sidebar -->
                                <div id="sidebar-wrapper">
                                    <ul class="sidebar-nav">
                                        <li>
                                            <a class="link-disfarcado" onclick="mostraAddImovel();">Adicionar Imóveis</a>
                                        </li>
                                        <li>
                                            <a class="link-disfarcado" onclick="mostraEditaImovel();">Editar Imóveis</a>
                                        </li>
                                        <li>
                                            <a class="link-disfarcado" onclick="mostraListaImovel();" >Listar Imóveis</a>
                                        </li>
                                        <li>
                                            <a class="link-disfarcado" onclick="mostraSlide();" >Slide [add / del]</a>
                                        </li>
                                        <li>
                                            <a class="link-disfarcado" onclick="mostraContato();" >Mensagens Recebidas</a>
                                        </li>
                                        <li>
                                            <a class="link-disfarcado" onclick="mostraSobre();">Editar Sobre</a>
                                        </li>
                                        <li>
                                            <a class="link-disfarcado" href="trocarSenha.php">Trocar Senha</a>
                                        </li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-9" id="secao-add-imovel">
                        <div class="col-md-12 esconderDepois">
                            <h2 class="text-center txt-espaco"> ADICIONAR IMÓVEIS</h2>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>


                            <div class="col-md-3 itens-menu-add">
                                <a href="#addImovelComercial" onclick="mostraSessaoAddComercial();"><center><span class="glyphicon glyphicon-usd icones-menu money"></span></center></a>
                            <h4 class="text-center ">IMÓVEIS <br> COMERCIAL</h4>

                            </div>    
                            <div class="col-md-3 itens-menu-add">
                                <a href="#addImovelResidencial" onclick="mostraSessaoAddResidencial();"><center><span class="glyphicon glyphicon-home icones-menu house"></span></center></a>
                            <h4 class="text-center ">IMÓVEIS RESIDENCIAL</h4>


                            </div>    
                            <div class="col-md-3 itens-menu-add">
                                <a href="#addImovelRural" onclick="mostraSessaoAddRural();"><center><span class="glyphicon glyphicon-leaf icones-menu rural"></span></center></a>
                                <h4 class="text-center ">IMOVÉIS <br> RURAL </h4>
                            </div>    
                            <div class="col-md-3 itens-menu-add">
                                <a href="#addImovelTerreno" onclick="mostraSessaoAddTerreno();"><center><span class="glyphicon glyphicon-th icones-menu terreno"></span></center></a>
                                <h4 class="text-center ">IMOVÉIS <br> TERRENO </h4>
                            </div> 
                        </div>
                    
                         <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>
                         <!-- CADASTRO DE IMÓVEIS COMERCIAL-->
                         <div class="col-md-12" id="addImovelComercial">
                            <span onclick="remostra();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">ADICIONAR IMÓVEL COMERCIAL</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>
                            <div class="container">
                                <form name="formAddComercial" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data">        
                                    <div class="col-md-9">
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Tipo de Negócio</label>
                                                    <select class="form-control diferente-adm" name="negocioComercial" required="" id="negocio">
                                                        <option class="option-select-padrao" value="aluguel">Aluguel</option>
                                                    </select>
                                                </div>
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Imóveis</label>
                                                    <select class="form-control diferente-adm" name="tipoComercial" required="" id="tipoComercial">
                                                        <option class="option-select-padrao" value="padrao">Selecione o tipo de imóvel</option>
                                                        <option class="option-select-padrao" value="Sala">Sala</option>
                                                        <option class="option-select-padrao" value="Lojas">Lojas</option>
                                                        <option class="option-select-padrao" value="SalaLiving">Sala Living</option>
                                                        <option class="option-select-padrao" value="Galpao">Galpão</option>
                                                        <option class="option-select-padrao" value="Predio">Prédio</option>
                                                        <option class="option-select-padrao" value="PontoComercial">Ponto Comercial</option>
                                                        <option class="option-select-padrao" value="AndarComercial">Andar Comercial</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Cidade</label>
                                                    <select class="form-control diferente-adm" name="cidadeComercial" required="" id="cidade">
                                                        <option class="option-select-padrao" value="eunapolis">Eunapolis</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Bairro</label>
                                                    <select class="form-control diferente-adm" name="bairroComercial" id="bairro">
                                                        <option class="option-select-padrao" value="padrao">Selecione o Bairro</option>
                                                        <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                                        <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                                        <option class="option-select-padrao" value="Centauro">Centauro</option>
                                                        <option class="option-select-padrao" value="Centro">Centro</option>
                                                        <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                                        <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                                        <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                                        <option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
                                                        <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                                        <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                                        <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                                        <option class="option-select-padrao" value="Motor">Motor</option>
                                                        <option class="option-select-padrao" value="Pequi">Pequi</option>
                                                        <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                                        <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                                        <option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
                                                        <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                                        <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                                        <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                                        <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                                        <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                                        <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                                        <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                                        <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                                        <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                                        <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                                        <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Rua</label>
                                                    <input type="text" name="ruaComercial" class="form-control diferente-adm" required="" placeholder="Informe a rua">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Número</label>
                                                    <input type="text" name="numeroComercial" class="form-control diferente-adm" required="" placeholder="Informe o número">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Nome do Proprietário</label>
                                                    <input type="text" name="nomeProprietarioComercial" class="form-control diferente-adm" required="" placeholder="Informe o nome do proprietário">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Telefone do Proprietário</label>
                                                    <input type="text" name="telefoneProprietarioComercial" class="form-control diferente-adm" required="" placeholder="Informe o número" id="telefone">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área Construída (m²)</label>
                                                    <input type="text" name="areaConstruidaComercial" class="form-control diferente-adm" required="" placeholder="Informe área construída em m²">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área do Terreno (m²)</label>
                                                    <input type="text" name="areaTerrenoComercial" class="form-control diferente-adm" required="" placeholder="Informe a área do terreno em m²" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Valor R$</label>
                                                    <input type="text" class="form-control diferente-adm dinheiro" name="valorComercial" >
                                                </div>  
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Observações</label>
                                                    <textarea class="form-control diferente-adm mensagem" rows="7" name="observacoesComercial"></textarea>

                                                </div>  
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Status</label>
                                                    <div class="col-md-3">
                                                        <input id="ativo" type="radio" name="statusComercial"  value="ativo" ><label class="control-label padding-label label-painel" for="ativo"> Ativo </label>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input id="passivo" type="radio" name="statusComercial" value="inativo" ><label class="control-label padding-label label-painel" for="passivo"> Inativo </label>
                                                    </div>
                                                </div>  
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12"><label class="col-sm-12 control-label padding-label label-painel">Fotos</label></div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <input type="file" class=" files" name="foto[]" multiple> <br>
                                                </div>
                                            </div> 
                                        </div>
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="col-md-12">
                                                    <button class="bt-secundario col-md-12 col-sm-12 col-xs-12" name="cadastrarComercial">CADASTRAR</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div> 
                        </div>
                        <!-- FIM CADASTRO DE IMÓVEIS RESIDENCIAL-->

                        <!-- CADASTRO DE IMÓVEIS RESIDENCIAL-->
                        <div class="col-md-12" id="addImovelResidencial">
                            <span onclick="remostra();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">ADICIONAR IMÓVEL RESIDENCIAL</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>
                            <div class="container">
                                <form name="formAddResidencial" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data">         
                                    <div class="col-md-9">
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Tipo de Negócio</label>
                                                    <select class="form-control diferente-adm" name="negocioResidencial" required="" id="negocio">
                                                        <option class="option-select-padrao" value="venda">Venda</option>
                                                        <option class="option-select-padrao" value="aluguel">Aluguel</option>
                                                    </select>
                                                </div>
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Imóveis</label>
                                                    <select class="form-control diferente-adm" name="tipoResidencial" required="" id="tipoResidencial">
                                                        <option class="option-select-padrao" value="padrao">Selecione o tipo de imóvel</option>
                                                        <option class="option-select-padrao" value="Sobrado">Sobrado</option>
                                                        <option class="option-select-padrao" value="Casa">Casa</option>
                                                        <option class="option-select-padrao" value="Cobertura">Cobertura</option>
                                                        <option class="option-select-padrao" value="Kitnet">Kitnet</option>
                                                        <option class="option-select-padrao" value="Apartamento">Apartamento</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Cidade</label>
                                                    <select class="form-control diferente-adm" name="cidadeResidencial" required="" id="cidade">
                                                        <option class="option-select-padrao" value="eunapolis">Eunapolis</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Bairro</label>
                                                    <select class="form-control diferente-adm" name="bairroResidencial" id="bairro">
                                                        <option class="option-select-padrao" value="padrao">Selecione o Bairro</option>
                                                        <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                                        <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                                        <option class="option-select-padrao" value="Centauro">Centauro</option>
                                                        <option class="option-select-padrao" value="Centro">Centro</option>
                                                        <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                                        <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                                        <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                                        <option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
                                                        <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                                        <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                                        <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                                        <option class="option-select-padrao" value="Motor">Motor</option>
                                                        <option class="option-select-padrao" value="Pequi">Pequi</option>
                                                        <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                                        <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                                        <option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
                                                        <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                                        <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                                        <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                                        <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                                        <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                                        <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                                        <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                                        <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                                        <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                                        <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                                        <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Rua</label>
                                                    <input type="text" name="ruaResidencial" class="form-control diferente-adm" required="" placeholder="Informe a rua">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Número</label>
                                                    <input type="text" name="numeroResidencial" class="form-control diferente-adm" required="" placeholder="Informe o número">
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-4 col-sm-4 col-xs-4">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Número de Quartos</label>
                                                    <input type="text" name="numeroQuartos" class="form-control diferente-adm" required="" placeholder="Informe o número de Quartos">
                                                </div>
                                                <div class="col-md-4 col-sm-4 col-xs-4">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Número de Banheiros</label>
                                                    <input type="text" name="numeroBanheiros" class="form-control diferente-adm" required="" placeholder="Informe o número de Banheiros">
                                                </div>
                                                <div class="col-md-4 col-sm-4 col-xs-4">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Número de Suites</label>
                                                    <input type="text" name="numeroSuites" class="form-control diferente-adm" required="" placeholder="Informe o número de Suites">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Nome do Proprietário</label>
                                                    <input type="text" name="nomeProprietarioResidencial" class="form-control diferente-adm" required="" placeholder="Informe o nome do proprietário">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Telefone do Proprietário</label>
                                                    <input type="text" name="telefoneProprietarioResidencial" class="form-control diferente-adm" required="" placeholder="Informe o número" id="telefone">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área Construída (m²)</label>
                                                    <input type="text" name="areaConstruidaResidencial" class="form-control diferente-adm" required="" placeholder="Informe área construída em m²">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área do Terreno (m²)</label>
                                                    <input type="text" name="areaTerrenoResidencial" class="form-control diferente-adm" required="" placeholder="Informe a área do terreno em m²" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Valor R$</label>
                                                    <input type="text" class="form-control diferente-adm dinheiro" name="valorResidencial" id="money" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                                                </div>  
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Observações</label>
                                                    <textarea class="form-control diferente-adm mensagem" rows="7" name="observacoesResidencial"></textarea>

                                                </div>  
                                            </div>
                                        </div>
                                         <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Status</label>
                                                    <div class="col-md-3">
                                                        <input id="ativo" type="radio" name="statusResidencial"  value="ativo" ><label class="control-label padding-label label-painel" for="ativo"> Ativo </label>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input id="passivo" type="radio" name="statusResidencial" value="inativo" ><label class="control-label padding-label label-painel" for="passivo"> Inativo </label>
                                                    </div>
                                                </div>  
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12"><label class="col-sm-12 control-label padding-label label-painel">Fotos</label></div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <input type="file" class=" files" name="foto[]" multiple> <br>
                                                </div>
                                            </div> 
                                        </div>
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="col-md-12">
                                                    <button class="bt-secundario col-md-12 col-sm-12 col-xs-12" name="cadastrarResidencial">CADASTRAR</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div> 
                        </div> 
                        <!-- FIM CADASTRO DE IMÓVEIS RESIDENCIAL-->
                        <!-- CADASTRO DE IMÓVEIS RURAL-->
                        <div class="col-md-12" id="addImovelRural">
                            <span onclick="remostra();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">ADICIONAR IMÓVEL RURAL</h3>

                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>
                            <div class="container"> 
                                <form name="formAddRural" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data">
                                    <div class="col-md-9">
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Tipo de Negócio</label>
                                                    <select class="form-control diferente-adm" name="negocioRural" required="" id="negocio">
                                                        <option class="option-select-padrao" value="venda">Venda</option>
                                                    </select>
                                                </div>
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Imóveis</label>
                                                    <select class="form-control diferente-adm" name="tipoRural" required="" id="tipoRural">
                                                        <option class="option-select-padrao" value="padrao">Selecione o tipo de imóvel</option>
                                                        <option class="option-select-padrao" value="Fazenda">Fazenda</option>
                                                        <option class="option-select-padrao" value="Sítio">Sítio</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Cidade</label>
                                                    <select class="form-control diferente-adm" name="cidadeRural" required="" id="cidade">
                                                        <option class="option-select-padrao" value="eunapolis">Eunápolis</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Bairro</label>
                                                    <select class="form-control diferente-adm" name="bairroRural" id="bairro">
                                                        <option class="option-select-padrao" value="padrao">Selecione o Bairro</option>
                                                        <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                                        <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                                        <option class="option-select-padrao" value="Centauro">Centauro</option>
                                                        <option class="option-select-padrao" value="Centro">Centro</option>
                                                        <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                                        <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                                        <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                                        <option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
                                                        <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                                        <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                                        <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                                        <option class="option-select-padrao" value="Motor">Motor</option>
                                                        <option class="option-select-padrao" value="Pequi">Pequi</option>
                                                        <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                                        <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                                        <option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
                                                        <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                                        <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                                        <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                                        <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                                        <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                                        <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                                        <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                                        <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                                        <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                                        <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                                        <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Rua</label>
                                                    <input type="text" name="ruaRural" class="form-control diferente-adm" required="" placeholder="Informe a rua">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Número</label>
                                                    <input type="text" name="numeroRural" class="form-control diferente-adm" required="" placeholder="Informe o número">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Nome do Proprietário</label>
                                                    <input type="text" name="nomeProprietarioRural" class="form-control diferente-adm" required="" placeholder="Informe o nome do proprietário">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Telefone do Proprietário</label>
                                                    <input type="text" name="telefoneProprietarioRural" class="form-control diferente-adm" required="" placeholder="Informe o número" id="telefone">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área Construída (h)</label>
                                                    <input type="text" name="areaConstruidaHRural" class="form-control diferente-adm" required="" placeholder="Informe área construída em hectares">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área do Terreno (h)</label>
                                                    <input type="text" name="areaTerrenoHRural" class="form-control diferente-adm" required="" placeholder="Informe a área do terreno em hectares" >
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área Construída (Alqueires)</label>
                                                    <input type="text" name="areaConstruidaARural" class="form-control diferente-adm" required="" placeholder="Informe área construída em alqueires">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área do Terreno (Alqueires)</label>
                                                    <input type="text" name="areaTerrenoARural" class="form-control diferente-adm" required="" placeholder="Informe a área do terreno em alqueires" >
                                                </div>
                                            </div>
                                        </div>
                                            <div class="form-group">        
                                                <div class="col-sm-12 col-xs-12">
                                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                                        <label class="col-sm-12 control-label padding-label label-painel">Valor R$</label>
                                                        <input type="text" class="form-control diferente-adm dinheiro" name="valorRural">
                                                    </div>  
                                                </div>
                                            </div>
                                            <div class="form-group">        
                                                <div class="col-sm-12 col-xs-12">
                                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                                        <label class="col-sm-12 control-label padding-label label-painel">Observações</label>
                                                        <textarea class="form-control diferente-adm mensagem" rows="7" name="observacoesRural"></textarea>
                                                        
                                                    </div>  
                                                </div>
                                            </div>
                                             <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Status</label>
                                                    <div class="col-md-3">
                                                        <input id="ativo" type="radio" name="statusRural"  value="ativo" ><label class="control-label padding-label label-painel" for="ativo"> Ativo </label>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input id="passivo" type="radio" name="statusRural" value="inativo" ><label class="control-label padding-label label-painel" for="passivo"> Inativo </label>
                                                    </div>
                                                </div>  
                                            </div>
                                        </div>
                                            <div class="form-group">        
                                                <div class="col-sm-12 col-xs-12">
                                                    <div class="col-md-12"><label class="col-sm-12 control-label padding-label label-painel">Fotos</label></div>
                                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                                        <input type="file" class=" files" name="foto[]" multiple> <br>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="form-group">
                                                <div class="col-md-12">
                                                    <button class="bt-secundario col-md-12 col-sm-12 col-xs-12" name="cadastrarRural">CADASTRAR</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div> 
                            </div>
                        <!-- FIM CADASTRO DE IMÓVEIS RURAL-->
                        <!-- CADASTRO DE IMÓVEIS TERRENO-->
                        <div class="col-md-12" id="addImovelTerreno">
                            <span onclick="remostra();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">ADICIONAR TERRENO</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>
                            <div class="container">   
                                <form name="formAddTerreno" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" enctype="multipart/form-data">   
                                    <div class="col-md-9">
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Tipo de Negócio</label>
                                                    <select class="form-control diferente-adm" name="negocioTerreno" required="" id="negocio">
                                                        <option class="option-select-padrao" value="venda">Venda</option>
                                                    </select>
                                                </div>
                                                <div class="col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Imóveis</label>
                                                    <select class="form-control diferente-adm" name="tipoTerreno" required="" id="tipoTerreno">
                                                        <option class="option-select-padrao" value="Terreno">Terreno</option>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Cidade</label>
                                                    <select class="form-control diferente-adm" name="cidadeTerreno" required="" id="cidade">
                                                        <option class="option-select-padrao" value="eunapolis">Eunapolis</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Bairro</label>
                                                    <select class="form-control diferente-adm" name="bairroTerreno" id="bairro">
                                                        <option class="option-select-padrao" value="padrao">Selecione o Bairro</option>
                                                        <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                                        <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                                        <option class="option-select-padrao" value="Centauro">Centauro</option>
                                                        <option class="option-select-padrao" value="Centro">Centro</option>
                                                        <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                                        <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                                        <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                                        <option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
                                                        <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                                        <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                                        <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                                        <option class="option-select-padrao" value="Motor">Motor</option>
                                                        <option class="option-select-padrao" value="Pequi">Pequi</option>
                                                        <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                                        <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                                        <option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
                                                        <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                                        <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                                        <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                                        <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                                        <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                                        <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                                        <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                                        <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                                        <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                                        <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                                        <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Rua</label>
                                                    <input type="text" name="ruaTerreno" class="form-control diferente-adm" required="" placeholder="Informe a rua">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Número</label>
                                                    <input type="text" name="numeroTerreno" class="form-control diferente-adm" required="" placeholder="Informe o número">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Nome do Proprietário</label>
                                                    <input type="text" name="nomeProprietarioTerreno" class="form-control diferente-adm" required="" placeholder="Informe o nome do proprietário">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Telefone do Proprietário</label>
                                                    <input type="text" name="telefoneProprietarioTerreno" class="form-control diferente-adm" required="" placeholder="Informe o número" id="telefone">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label label-painel">Área Construída (m²)</label>
                                                    <input type="text" name="areaTerreno" class="form-control diferente-adm" required="" placeholder="Informe área construída em m²">
                                                </div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Valor R$</label>
                                                    <input type="text" class="form-control diferente-adm dinheiro" name="valorTerreno" id="money" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Observações</label>
                                                    <textarea class="form-control diferente-adm mensagem" rows="7" name="observacoesTerreno"></textarea>

                                                </div>  
                                            </div>
                                        </div>
                                         <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <label class="col-sm-12 control-label padding-label label-painel">Status</label>
                                                    <div class="col-md-3">
                                                        <input id="ativo" type="radio" name="statusTerreno"  value="ativo" ><label class="control-label padding-label label-painel" for="ativo"> Ativo </label>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input id="passivo" type="radio" name="statusTerreno" value="inativo" ><label class="control-label padding-label label-painel" for="passivo"> Inativo </label>
                                                    </div>
                                                </div>  
                                            </div>
                                        </div>
                                        <div class="form-group">        
                                            <div class="col-sm-12 col-xs-12">
                                                <div class="col-md-12"><label class="col-sm-12 control-label padding-label label-painel">Fotos</label></div>
                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                    <input type="file" class=" files" name="foto[]" multiple> <br>
                                                </div>
                                            </div> 
                                        </div>
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <button class="bt-secundario col-md-12 col-sm-12 col-xs-12" name="cadastrarTerreno">CADASTRAR</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div> 
                        </div>
                        <!-- FIM CADASTRO DE IMÓVEIS TERRENO-->
                    </div>
                    <!-- EDITAR IMÓVEIS-->
                    <div class="col-md-9" id="secao-edit-imovel">
                        <div class="col-md-12 esconderDepois">
                            <h2 class="text-center txt-espaco"> EDITAR IMÓVEIS</h2>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>

                            <div class="col-md-3 itens-menu-add">
                                <a href="#editaImovelComercial" onclick="mostraEditaComercial();"><center><span class="glyphicon glyphicon-usd icones-menu money"></span></center></a>
                                <h4 class="text-center">IMÓVEIS <br> COMERCIAL</h4>

                            </div>

                            <div class="col-md-3 itens-menu-add">
                                <a href="#editaImovelComercial" onclick="mostraEditaResidencial();"><center><span class="glyphicon glyphicon-home icones-menu house"></span></center></a>
                                <h4 class="text-center">IMÓVEIS RESIDENCIAL</h4>


                            </div>    
                           <div class="col-md-3 itens-menu-add">
                                <a href="#editaImovelRural" onclick="mostraEditaRural();"><center><span class="glyphicon glyphicon-leaf icones-menu rural"></span></center></a>
                                <h4 class="text-center">IMOVÉIS <br> RURAL </h4>
                            </div>  
                           <div class="col-md-3 itens-menu-add">
                                <a href="#addImovelTerreno" onclick="mostraEditaTerreno();"><center><span class="glyphicon glyphicon-th icones-menu terreno"></span></center></a>
                                <h4 class="text-center ">IMOVÉIS <br> TERRENO </h4>
                            </div> 
                        </div>
                        <!--EDITA IMOVEL COMERCIAL-->
                        <div class="col-md-12" id="editaImovelComercial">
                            <span onclick="remostraEdita();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">EDITAR IMÓVEL COMERCIAL</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>                          
                                <table class="table table-condensed table-striped ">
                                    <thead>
                                        <tr>
                                            <th>Ação</th>
                                            <th>Endereço</th>
                                            <th>Negócio</th>
                                            <th>Valor</th>
                                            <th><span class="badge">Código</span></th>
                                         </tr>
                                    </thead>
                                    <tbody>
                                
                                <?php 
                                    $qEditaComercial = "SELECT * FROM cadastroimovelcomercial";
                                    $executaEditaComercial = $mysqli->query($qEditaComercial);

                                    $cont = mysqli_num_rows($executaEditaComercial);

                                    if($cont != 0){
                                        while($row = mysqli_fetch_array($executaEditaComercial)){
                                            $codigo = $row['codigo'];
                                            $idEndereco = $row['idEndereco'];
                                            $idProprietario = $row['idProprietario'];
                                            $idTelefone = $row['idEndereco'];
                                            $negocio = $row['negocio'];
                                            $preco = $row['valor'];

                                            $qEnderecoEdita = "SELECT * FROM enderecos WHERE idEndereco  ='$idEndereco'";
                                            $executaEnderecosEdita = $mysqli->query($qEnderecoEdita);



                                            while($row2 = mysqli_fetch_array($executaEnderecosEdita)){
                                                $numero = $row2['numero'];
                                                $rua = $row2['rua'];
                                                $bairro = $row2['bairro'];
                                ?>          
                                    <tr>
                                        <td>
                                            <a href="editarImovel.php?idImovel=<?php echo "$codigo";?>"><button type="button" class="btn btn-primary">Editar <span class="glyphicon glyphicon-pencil"></span></button></a>
                                            <a href="javascript:func()" onclick="confirmacao('<?php echo "$codigo"; ?>','<?php echo "$idEndereco";?>', '<?php echo "$idTelefone"; ?>', '<?php echo "$idProprietario"; ?>')" class="btn btn-danger">Excluir <span class="glyphicon glyphicon-remove-circle"></span></a>
                                        </td>
                                        <td><?php echo"$rua, $numero, $bairro";?></td>
                                        <td><?php echo"$negocio";?></td>
                                        <td><?php echo"$preco";?></td>
                                        <td><span class="badge"><?php echo "$codigo"; ?></span></td>
                                    </tr></a>
                                
                                <?php
                                    }
                                        }
                                    }

                                ?>
                                    </tbody>
                                </table>
                        </div>
                        <!--FIM EDITAR IMOVEL COMERCIAL-->

                        <!--EDITA IMOVEL RESIDENCIAL-->
                        <div class="col-md-12" id="editaImovelResidencial">
                            <span onclick="remostraEdita();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">EDITAR IMÓVEL RESIDENCIAL</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>                          
                                <table class="table table-condensed table-striped ">
                                    <thead>
                                        <tr>
                                            <th>Ação</th>
                                            <th>Endereço</th>
                                            <th>Negócio</th>
                                            <th>Valor</th>
                                            <th><span class="badge">Código</span></th>
                                         </tr>
                                    </thead>
                                    <tbody>
                                
                                <?php 
                                    $qEditaResidencial = "SELECT * FROM cadastroimovelresidencial";
                                    $executaEditaResidencial = $mysqli->query($qEditaResidencial);

                                    $cont = mysqli_num_rows($executaEditaResidencial);

                                    if($cont != 0){
                                        while($row = mysqli_fetch_array($executaEditaResidencial)){
                                            $codigo = $row['codigo'];
                                            $idEndereco = $row['idEndereco'];
                                            $negocio = $row['negocio'];
                                            $preco = $row['valor'];

                                            $qEnderecoEdita = "SELECT * FROM enderecos WHERE idEndereco  ='$idEndereco'";
                                            $executaEnderecosEdita = $mysqli->query($qEnderecoEdita);

                                            while($row2 = mysqli_fetch_array($executaEnderecosEdita)){
                                                $numero = $row2['numero'];
                                                $rua = $row2['rua'];
                                                $bairro = $row2['bairro'];
                                ?>          
                                    <tr>
                                        <td>
                                            <a href="editarImovelResidencial.php?idImovel=<?php echo "$codigo";?>"><button type="button" class="btn btn-primary">Editar <span class="glyphicon glyphicon-pencil"></span></button></a>
                                            <a href="javascript:func()" onclick="confirmacao('<?php echo "$codigo"; ?>','<?php echo "$idEndereco";?>', '<?php echo "$idTelefone"; ?>', '<?php echo "$idProprietario"; ?>')" class="btn btn-danger">Excluir <span class="glyphicon glyphicon-remove-circle"></span></a>
                                        </td>
                                        <td><?php echo"$rua, $numero, $bairro";?></td>
                                        <td><?php echo"$negocio";?></td>
                                        <td><?php echo"$preco";?></td>
                                        <td><span class="badge"><?php echo "$codigo"; ?></span></td>
                                    </tr></a>
                                
                                <?php
                                    }
                                        }
                                    }

                                ?>
                                    </tbody>
                                </table>
                        </div>
                        <!--FIM EDITAR IMOVEL RESIDENCIAL-->

                        <!--EDITA IMOVEL RURAL-->
                        <div class="col-md-12" id="editaImovelRural">
                            <span onclick="remostraEdita();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">EDITAR IMÓVEL RURAL</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>                          
                                <table class="table table-condensed table-striped ">
                                    <thead>
                                        <tr>
                                            <th>Ação</th>
                                            <th>Endereço</th>
                                            <th>Negócio</th>
                                            <th>Valor</th>
                                            <th><span class="badge">Código</span></th>
                                         </tr>
                                    </thead>
                                    <tbody>
                                
                               <?php   
                                    $qEditaRural = "SELECT * FROM cadastrorural";
                                    $executaEditaRural = $mysqli->query($qEditaRural);

                                    $cont = mysqli_num_rows($executaEditaRural);

                                    if($cont != 0){
                                        while($row = mysqli_fetch_array($executaEditaRural)){
                                            $codigo = $row['codigo'];
                                            $idEndereco = $row['idEndereco'];
                                            $negocio = $row['negocio'];
                                            $preco = $row['valor'];

                                            $qEnderecoEdita = "SELECT * FROM enderecos WHERE idEndereco  ='$idEndereco'";
                                            $executaEnderecosEdita = $mysqli->query($qEnderecoEdita);

                                            while($row2 = mysqli_fetch_array($executaEnderecosEdita)){
                                                $numero = $row2['numero'];
                                                $rua = $row2['rua'];
                                                $bairro = $row2['bairro'];
                                ?>        
                                    <tr>
                                        <td>
                                            <a href="editarImovelRural.php?idImovel=<?php echo "$codigo";?>"><button type="button" class="btn btn-primary">Editar <span class="glyphicon glyphicon-pencil"></span></button></a>

                                            <a href="javascript:func()" onclick="confirmacao('<?php echo "$codigo"; ?>','<?php echo "$idEndereco";?>', '<?php echo "$idTelefone"; ?>', '<?php echo "$idProprietario"; ?>')" class="btn btn-danger">Excluir <span class="glyphicon glyphicon-remove-circle"></span></a>
                                        </td>
                                        <td><?php echo"$rua, $numero, $bairro";?></td>
                                        <td><?php echo"$negocio";?></td>
                                        <td><?php echo"$preco";?></td>
                                        <td><span class="badge"><?php echo "$codigo"; ?></span></td>
                                    </tr></a>
                                
                                <?php
                                    }
                                        }
                                    }

                                ?>
                                    </tbody>
                                </table>
                        </div>
                        <!--FIM EDITAR IMOVEL RURAL-->
                          <!--EDITA IMOVEL TERRENO-->
                        <div class="col-md-12" id="editaImovelTerreno">
                            <span onclick="remostraEdita();" class="volta">Voltar</span>
                            <h3 class="text-center txt-espaco">EDITAR TERRENO</h3>
                            <label for="" class="col-sm-12 col-xs-12 control-label padding-label"></label>                          
                                <table class="table table-condensed table-striped ">
                                    <thead>
                                        <tr>
                                            <th>Ação</th>
                                            <th>Endereço</th>
                                            <th>Negócio</th>
                                            <th>Valor</th>
                                            <th><span class="badge">Código</span></th>
                                         </tr>
                                    </thead>
                                    <tbody>
                                
                               <?php   
                                    $qEditaTerreno = "SELECT * FROM cadastroterreno";
                                    $executaEditaTerreno = $mysqli->query($qEditaTerreno);

                                    $cont = mysqli_num_rows($executaEditaTerreno);

                                    if($cont != 0){
                                        while($row = mysqli_fetch_array($executaEditaTerreno)){
                                            $codigo = $row['codigo'];
                                            $idEndereco = $row['idEndereco'];
                                            $negocio = $row['negocio'];
                                            $preco = $row['valor'];

                                            $qEnderecoEdita = "SELECT * FROM enderecos WHERE idEndereco  ='$idEndereco'";
                                            $executaEnderecosEdita = $mysqli->query($qEnderecoEdita);

                                            while($row2 = mysqli_fetch_array($executaEnderecosEdita)){
                                                $numero = $row2['numero'];
                                                $rua = $row2['rua'];
                                                $bairro = $row2['bairro'];
                                ?>        
                                    <tr>
                                        <td>
                                            <a href="editarImovelTerreno.php?idImovel=<?php echo "$codigo";?>"><button type="button" class="btn btn-primary">Editar <span class="glyphicon glyphicon-pencil"></span></button></a>

                                            <a href="javascript:func()" onclick="confirmacao('<?php echo "$codigo"; ?>','<?php echo "$idEndereco";?>', '<?php echo "$idTelefone"; ?>', '<?php echo "$idProprietario"; ?>')" class="btn btn-danger">Excluir <span class="glyphicon glyphicon-remove-circle"></span></a>
                                        </td>
                                        <td><?php echo"$rua, $numero, $bairro";?></td>
                                        <td><?php echo"$negocio";?></td>
                                        <td><?php echo"$preco";?></td>
                                        <td><span class="badge"><?php echo "$codigo"; ?></span></td>
                                    </tr></a>
                                
                                <?php
                                    }
                                        }
                                    }

                                ?>
                                    </tbody>
                                </table>
                        </div>
                        <!--FIM EDITAR TERRENO-->
                    </div>
                    <!--FIM EDITAR IMÓVEIS-->

                    <!-- LISTAR IMÓVEIS-->
                    <div class="col-md-9" id="secao-list-imovel">
                       
                        <!--BUSCA IMOVEIS ADM-->
                        <div class="container">
                            <div class="col-md-9">
                                  <h2 class="text-center espaco-text  bold">BUSCAR IMÓVEIS</h2>
                            </div>
                            <div class="col-md-12">
                                <form method="POST" action="buscarADM.php">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="inputPassword3" class="col-sm-8 control-label padding-label">Busca Específica</label>
                                            <div class="col-sm-12">
                                                <select class="form-control diferente-adm col-md-12" name="tipoTop" required="" id="tipoTop" onchange="ChamarLink();">
                                                    <option class="option-select-padrao" value="padrao">Tipo do Imóvel</option>
                                                    <option class="option-select-padrao" value="comercial">Comercial</option>
                                                    <option class="option-select-padrao" value="residencial">Residencial</option>
                                                    <option class="option-select-padrao" value="rural">Rural</option>
                                                    <option class="option-select-padrao" value="terreno">Terreno</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8"></div>
                            </div>
                            <!-- BUSCA COMERCIAL -->
                            <div class="col-md-12"></div>
                <div class="col-md-9" id="comercial">
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Tipo de Negócio</label>
                                <select class="form-control diferente-adm" name="negocioComercial" required="" id="negocio">
                                    <option class="option-select-padrao" value="aluguel">Aluguel</option>
                                </select>
                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Imóveis</label>
                                <select class="form-control diferente-adm" name="tipoComercial" required="" id="tipoComercial">
                                    <option class="option-select-padrao" value="padrao">Todos</option>
                                    <option class="option-select-padrao" value="sala">Sala</option>
                                    <option class="option-select-padrao" value="lojas">Lojas</option>
                                    <option class="option-select-padrao" value="salaliving">Sala Living</option>
                                    <option class="option-select-padrao" value="galpao">Galpão</option>
                                    <option class="option-select-padrao" value="predio">Prédio</option>
                                    <option class="option-select-padrao" value="pontocomercial">Ponto Comercial</option>
                                    <option class="option-select-padrao" value="andarcomercial">Andar Comercial</option>

                                </select>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group">
                        <div class="col-sm-12 col-xs-12">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Cidade</label>
                                <select class="form-control diferente-adm" name="cidadeComercial" required="" id="cidade">
                                    <option class="option-select-padrao" value="Eunápolis">Eunapolis</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label class="col-sm-12 control-label padding-label">Bairro</label>
                                <select class="form-control diferente-adm" name="bairroComercial" id="bairro">
                                    <option class="option-select-padrao" value="padrao">Todos</option>
                                    <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                    <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                    <option class="option-select-padrao" value="Centauro">Centauro</option>
                                    <option class="option-select-padrao" value="Centro">Centro</option>
                                    <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                    <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                    <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                    <option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
                                    <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                    <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                    <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                    <option class="option-select-padrao" value="Motor">Motor</option>
                                    <option class="option-select-padrao" value="Pequi">Pequi</option>
                                    <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                    <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                    <option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
                                    <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                    <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                    <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                    <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                    <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                    <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                    <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                    <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                    <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                    <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                    <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>


                                </select>


                            </div>

                        </div>
                    </div>
                    <div class="form-group">        
                        <div class="col-sm-12 col-xs-12">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label class="col-sm-12 control-label padding-label">Valor Mínimo R$</label>
                                <input type="text" class="form-control diferente-adm dinheiro" name="valorMinimoComercial" id="money" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                            </div>  
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label class="col-sm-12 control-label padding-label">Valor Máximo R$</label>
                                <input type="text" class="form-control diferente-adm dinheiro" name="valorMaximoComercial" id="money2" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
                            <button class="bt-secundario col-md-12 col-sm-12 col-xs-12" name="bt-comercial-adm">BUSCAR</button>
                        </div>
                    </div>
                </div>      

                <!-- FIM DA BUSCA COMERCIAL -->

                <!-- BUSCA RESIDENCIAL --> 
                <div class="col-md-9" id="residencial">

                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="col-sm-6 col-md-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Tipo de Negócio</label>
                                <select class="form-control diferente-adm" name="negocioResidencial" required="" id="negocio">
                                    <option class="option-select-padrao" value="padrao">Selecione o tipo de Negócio</option>
                                    <option class="option-select-padrao" value="Aluguel">Aluguel</option>
                                    <option class="option-select-padrao" value="Venda">Venda</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Imóveis</label>
                                <select class="form-control diferente-adm" name="tipoResidencial" required="" id="tipoResidencial">
                                    <option class="option-select-padrao" value="padrao">Selecione o tipo de imóvel</option>
                                    <option class="option-select-padrao" value="Apartamento">Apartamento</option>
                                    <option class="option-select-padrao" value="Casa">Casa</option>
                                    <option class="option-select-padrao" value="Cobertura">Cobertura</option>
                                    <option class="option-select-padrao" value="Kitnet">Kitnet</option>
                                    <option class="option-select-padrao" value="Sobrado">Sobrado</option>
                                </select>
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-sm-12 col-xs-12">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Cidade</label>
                                <select class="form-control diferente-adm" name="cidadeResidencial" required="" id="cidade">
                                    <option class="option-select-padrao" value="Eunápolis">Eunapolis</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Bairro</label>
                                <select class="form-control diferente-adm" name="bairroResidencial" required="" id="bairro">
                                    <option class="option-select-padrao" value="padrao">Selecione o Bairro</option>
                                    <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                    <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                    <option class="option-select-padrao" value="Centauro">Centauro</option>
                                    <option class="option-select-padrao" value="Centro">Centro</option>
                                    <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                    <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                    <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                    <option class="option-select-padrao" value="Jardins de eunapolis">Jardins De Eunápolis</option>
                                    <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                    <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                    <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                    <option class="option-select-padrao" value="Motor">Motor</option>
                                    <option class="option-select-padrao" value="Pequi">Pequi</option>
                                    <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                    <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                    <option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
                                    <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                    <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                    <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                    <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                    <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                    <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                    <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                    <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                    <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                    <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                    <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>


                                </select>


                            </div>

                        </div>
                    </div>

                    <div class="form-group">        
                        <div class="col-sm-12 col-xs-12">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Mínimo R$</label>
                                <input type="text" class="form-control diferente-adm dinheiro" name="valorMinimoResidencial" id="money3" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                            </div>  
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Máximo R$</label>
                                <input type="text" class="form-control diferente-adm dinheiro" name="valorMaximoResidencial" id="money4" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12 col-xs-12">
                            <div class="col-md-4 col-sm-4 col-xs-4">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Nº Quartos</label>
                                <input type="number" class="form-control diferente-adm " name="Nquartos" min="1" value="1" />
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-4">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Nº Suítes</label>
                                <input type="number" class="form-control diferente-adm " name="Nsuites" min="0" value="0" />

                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-4">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Nº Banheiros</label>
                                <input type="number" class="form-control diferente-adm " name="Nbanheiros" min="1" value="1"  id="banheiro" />
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-12">
                            <label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
                            <button class="bt-principal diferente-adm col-md-12 col-sm-12 col-xs-12" name="bt-residencial-adm" id="busca-residencial-adm">BUSCAR</button>
                        </div>
                    </div>

                </div>
                <!-- FIM DE BUSCA RESIDENCIA -->

                <!-- BUSCA RURAL -->

                <div class="col-md-9" id="rural">
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="col-sm-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Tipo de Negócio</label>
                                <select class="form-control diferente-adm" name="negocioRural" required="" id="negocio">
                                    <option class="option-select-padrao" value="venda">Venda</option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Imóveis</label>
                                <select class="form-control diferente-adm" name="tipoRural" required="" id="tipoRural">
                                    <option class="option-select-padrao" value="padrao">Selecione o tipo de Imóvel</option>
                                    <option class="option-select-padrao" value="fazenda">Fazenda</option>
                                    <option class="option-select-padrao" value="sitio">Sítio</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                        <div class="col-sm-12 col-xs-12">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Cidade</label>
                                <select class="form-control diferente-adm" name="cidadeRural" required="" id="cidade">
                                    <option class="option-select-padrao" value="Eunápolis">Eunapolis</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Bairro</label>
                                <select class="form-control diferente-adm" name="bairroRural" required="" id="bairro">
                                    <option class="option-select-padrao" value="padrao">Selecione o Bairro</option>
                                    <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                    <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                    <option class="option-select-padrao" value="Centauro">Centauro</option>
                                    <option class="option-select-padrao" value="Centro">Centro</option>
                                    <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                    <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                    <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                    <option class="option-select-padrao" value="Jardins de eunapolis">Jardins De Eunápolis</option>
                                    <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                    <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                    <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                    <option class="option-select-padrao" value="Motor">Motor</option>
                                    <option class="option-select-padrao" value="Pequi">Pequi</option>
                                    <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                    <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                    <option class="option-select-padrao" value="Santa Lúcia">Santa Lúcia</option>
                                    <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                    <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                    <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                    <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                    <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                    <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                    <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                    <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                    <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                    <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                    <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>


                                </select>


                            </div>

                        </div>
                    </div>
                        <div class="form-group">        
                            <div class="col-sm-12 col-xs-12">
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Mínimo R$</label>
                                    <input type="text" class="form-control diferente-adm dinheiro" name="valorMinimoRural" id="money5" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                                </div>  
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Máximo R$</label>
                                    <input type="text" class="form-control diferente-adm dinheiro" name="valorMaximoRural" id="money6" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
                            <button class="bt-principal diferente-adm col-md-12 col-sm-12 col-xs-12" name="bt-rural-adm" id="busca-rural">BUSCAR</button>
                        </div>
                    </div>
                </div>
                <!-- FIM BUSCA RURAL -->

                <!-- BUSCA TERRENO -->
                <div class="col-md-9" id="terreno">
                    <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Cidade</label>
                                <select class="form-control diferente-adm" name="cidadeTerreno" required="" id="cidade">
                                    <option class="option-select-padrao" value="Eunápolis">Eunapolis</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Bairro</label>
                                <select class="form-control diferente-adm" name="bairroTerreno" id="bairro">
                                    <option class="option-select-padrao" value="padrao">Todos</option>
                                    <option class="option-select-padrao" value="Alecrim">Alecrim</option>
                                    <option class="option-select-padrao" value="Cajueiro">Cajueiro</option>
                                    <option class="option-select-padrao" value="Centauro">Centauro</option>
                                    <option class="option-select-padrao" value="Centro">Centro</option>
                                    <option class="option-select-padrao" value="Dinah Borges">Diná Borges</option>
                                    <option class="option-select-padrao" value="Doutor Gusmão">Doutor Gusmão</option>
                                    <option class="option-select-padrao" value="Itapuã">Itapuã</option>
                                    <option class="option-select-padrao" value="Jardins de Eunápolis">Jardins De Eunápolis</option>
                                    <option class="option-select-padrao" value="Juca Rosa">Juca Rosa</option>
                                    <option class="option-select-padrao" value="Minas Gerais">Minas Gerais</option>
                                    <option class="option-select-padrao" value="Moises Réis">Moisés Reis</option>
                                    <option class="option-select-padrao" value="Motor">Motor</option>
                                    <option class="option-select-padrao" value="Pequi">Pequi</option>
                                    <option class="option-select-padrao" value="Rosa Neto">Rosa Neto</option>
                                    <option class="option-select-padrao" value="Santa Isabel">Santa Isabel</option>
                                    <option class="option-select-padrao" value="Santa Lúcia">Santa Lucia</option>
                                    <option class="option-select-padrao" value="Sapucaeira">Sapucaeira</option>
                                    <option class="option-select-padrao" value="Stela Réis">Stela Reis</option>
                                    <option class="option-select-padrao" value="Edgar Trancoso">Edgar Trancoso</option>
                                    <option class="option-select-padrao" value="Urbis 1">Urbis I</option>
                                    <option class="option-select-padrao" value="Urbis 2">Urbis II</option>
                                    <option class="option-select-padrao" value="Urbis 3">Urbis III</option>
                                    <option class="option-select-padrao" value="Vivendas Costa Azul">Vivendas Costa Azul</option>
                                    <option class="option-select-padrao" value="Gabiarra">Gabiarra</option>
                                    <option class="option-select-padrao" value="Mundo Novo">Mundo Novo</option>
                                    <option class="option-select-padrao" value="Projeto Maravilha">Projeto Maravilha</option>
                                    <option class="option-select-padrao" value="Roça do Povo">Roça do Povo</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Mínimo R$</label>
                                <input type="text" class="form-control diferente-adm dinheiro" name="valorMinimoTerreno" id="money5" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                            </div>  
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <label for="inputPassword3" class="col-sm-12 control-label padding-label">Valor Máximo R$</label>
                                <input type="text" class="form-control diferente-adm dinheiro" name="valorMaximoTerreno" id="money6" onKeyPress="return(MascaraMoeda(this,'.',',',event))">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-md-12">
                            <label for="inputPassword3" class="col-sm-12 control-label padding-label"> </label>
                            <button class="bt-principal diferente-adm col-md-12 col-sm-12 col-xs-12" name="bt-terreno-adm" id="busca-terreno">BUSCAR</button>
                        </div>
                    </div>
                </div>
            </form>
            <div class="container">
                    
          
                <div class="col-md-12">
                    <label for="inputPassword3" class="col-sm-8 control-label padding-label"></label>
                    <label for="inputPassword3" class="col-sm-8 control-label padding-label">Busca por código</label>
                    <form  name="buscaCodigo" method="POST" action="ImovelEspecificoADM.php">
                            <div class="form-group">
                                <div class="col-sm-9 col-xs-9">
                                    <input type="text" class="form-control diferente diferente-adm" name="idImovel" placeholder="Buscar por código, Ex: A001, C001, T001" id="email">
                                </div>
                                <label for="inputPassword3" class="col-sm-8 control-label padding-label"></label>
                                <div class="col-sm-9 col-xs-9">
                                    <button type="submit" class="bt-secundario col-md-12" name="bt-codigo">BUSCAR</button>
                                </div>
                            </div>
                        </form>
                </div>
            </div>
            
            <!-- FIM BUSCA TERRENO -->
                    </div>
                </div>
                    

                    <!-- FIM LISTAR IMOVEIS -->
                    <!-- INICIO  MENSAGEM -->

                     <div class="col-md-9" id="mostrarContatos">
                        <div class="col-md-12 esconderDepois" >
                            <h2 class="text-center txt-espaco"> Mensagens Recebidas</h2>
                            <?php
                                $qContato = "SELECT * FROM contatos";
                                $qqContato = $mysqli->query($qContato);

                                $CONTADOR = mysqli_num_rows($qqContato);

                                if($CONTADOR > 0){
                                     $i = 1;

                                ?>
                                   
                                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                    <?php while($row = mysqli_fetch_array($qqContato)){
                                        $codigo = $row['id'];
                                        $nome = $row['nome'];
                                        $email = $row['email'];
                                        $telefone = $row['telefone'];
                                        $mensagem = $row['mensagem'];

                                        $id = "heading".$i;
                                        $areaControls =  "collapse".$i;
                                        $href = "#collapse".$i;

                                        if($id == "heading1"){
                                            $expanded = "true";
                                            $class = "";
                                            $class2 = "";
                                        }else{
                                            $expanded = "false";
                                            $class = "collapsed";
                                            $class2 = "";
                                        }

        
                                    ?>

                                        
                                          <div class="panel panel-default">
                                            <div class="panel-heading" role="tab" id="<?php echo"$id"; ?>">
                                              <h4 class="panel-title">
                                                <a class="<?php echo "$class"; ?>" role="button" data-toggle="collapse" data-parent="#accordion" href="<?php echo "$href"; ?>" aria-expanded="<?php echo "$expanded"; ?>" aria-controls="<?php echo"$areaControls"; ?>">
                                                  Mensagem <span class="badge direita"><?php echo "$codigo"; ?></span>
                                                </a>
                                              </h4>
                                            </div>
                                            <div id="<?php echo"$areaControls"; ?>" class="panel-collapse collapse <?php echo "$class2"; ?>" role="tabpanel" aria-labelledby="<?php echo"$id"; ?>">
                                              <div class="panel-body">
                                               <ul class="lista-contatos">
                                                    <li><?php echo "Nome: $nome <br>"; ?></li>
                                                    <li><?php echo "E-mail: $email <br>"; ?></li>
                                                    <li><?php echo "Telefone: $telefone "; ?></li>
                                                    <li><?php echo "Mensagem: <br> $mensagem"; ?></li>
                                                </ul>
                                              </div>
                                            </div>
                                          </div>
            
                                    <?php
                                    $i++;}
                                }

                                    ?>
                            </div>
                        </div>
                        <!-- FIM MENSAGENS -->
                    </div>
                    <!-- INICIO  SOBRE -->
                     <div class="col-md-9" id="mostrarSobre">
                        <div class="col-md-12 esconderDepois" >
                            <h2 class="text-center txt-espaco"> EDITAR SOBRE</h2>
                            <?php
                                $qSobre = "SELECT * FROM sobre";
                                $qqSobre = $mysqli->query($qSobre);

                                $CONTADOR = mysqli_num_rows($qqSobre);

                                if($CONTADOR >= 0){
                                    

                                ?>
                                   
                                
                                    
                                    <?php while($row = mysqli_fetch_array($qqSobre)){

                                        $mensagem = $row['descricao'];
                                        $id = $row['idSobre'];


                                    ?>
                                    <form name="sobre" method="POST" action="painel.php?idSobre=<?php echo "$id"; ?> ">
                                        <div class="form-group">
                                        <textarea type="text" class="form-control transparente mensagem"  name="textoSobre" rows="10"><?php echo "$mensagem"; ?></textarea>

                                        
            
                                    <?php
                                    }
                                }

                                    ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="bt-principal col-md-12 sem-fundo s" name="enviarSobre">ATUALIZAR</button>

                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- FIM SOBRE -->
                        <!-- INICIO  SLIDE -->

                        <div class="col-md-9" id="mostrarSlide">
                            <div class="col-md-12 esconderDepois" >
                                <h2 class="text-center txt-espaco"> ADICIONAR SLIDE</h2>
                                <form class="form" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                                    <div class="form-group">        
                                        <div class="col-sm-12 col-xs-12">
                                            <div class="col-md-12">
                                                <label class="col-sm-12 control-label padding-label label-painel">Adicionar Foto</label>
                                            </div>
                                            <div class="col-md-6 col-sm-6 col-xs-6">
                                                <input type="file" class=" files" name="fotosSlide[]"> <br>
                                            </div>
                                            <div class="col-md-12"><label class="col-sm-12 control-label padding-label label-painel"> Use 1943px X 500px como dimensão</label></div>
                                        </div> 
                                    </div>

                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button class="bt-secundario col-md-12 col-sm-12 col-xs-12" name="adicionarSlide" type="submit">CADASTRAR SLIDE</button>
                                        </div>
                                    </div>
                                </form>
                                <label class="col-sm-12 control-label padding-label label-painel"></label>
                                <label class="col-sm-12 control-label padding-label label-painel"></label>
                                <label class="col-sm-12 control-label padding-label label-painel"></label>
                                <label class="col-sm-12 traco"></label>
                                <div class="col-md-12">
                                    <h2 class="text-center txt-espaco"> REMOVER SLIDE</h2>
                                    <div class="row">
                                        
    
                                </div>
                                <?php
                                    $qSlide = "SELECT * FROM slide";
                                    $qqSlide = $mysqli->query($qSlide);

                                    while ($row = mysqli_fetch_array($qqSlide)) {
                                        $id = $row['idSlide'];
                                        $descricao = $row['descricao'];
                                        $foto = $row['caminho'];
                                        
                                 ?>
                                        <div class="col-sm-6 col-md-4">
                                            <div class="thumbnail">
                                                <img src="../img/img-slider/<?php echo "$foto"; ?>" alt="<?php echo "$descricao"; ?>"/>
                                                <div class="caption">
                                                    <h3 class="text-center">Foto <?php echo "$id"; ?></h3>
                                                </div>
                                                <a href="javascript:func()" onclick="confirmacaoSlide('<?php echo "$id"; ?>')" class="btn btn-danger">Excluir Slide <span class="glyphicon glyphicon-remove-circle"></span></a>
                                
                                            </div>
                                        </div>

                                 <?php
                                    }
                                 ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                            
                        <!-- FIM SOBRE -->
                
                
                
            </div>
        </div>
    </section>
        <!--JAVASCRIPT INICIO-->
            <script type="text/javascript">
                function aparece() {
                    $('.aparecer').show('slow');
                }
                function mostraAddImovel(){
                    $('#secao-add-imovel').show('slow');
                    $('#secao-edit-imovel').hide('slow');
                    $('#secao-del-imovel').hide('slow');
                    $('#secao-list-imovel').hide('slow');
                    $('#mostrarSlide').hide('slow');
                    $('#mostrarContatos').hide('slow');
                    $('#mostrarSobre').hide('slow');
                    $('#secao-relatorios').hide('slow');
                    //venis//
                    $('#addImovelComercial').hide('slow');
                    $('#addImovelResidencial').hide('slow');
                    $('#addImovelTerreno').hide('slow');
                    $('#addImovelRural').hide('slow');
                    $('.esconderDepois').show('slow');
                    //venis//
                }
                function mostraEditaImovel(){
                    $('#secao-add-imovel').hide('slow');
                    $('#secao-edit-imovel').show('slow');
                    $('#secao-del-imovel').hide('slow');
                    $('#secao-list-imovel').hide('slow');
                    $('#mostrarSlide').hide('slow');
                    $('#mostrarContatos').hide('slow');
                    $('#mostrarSobre').hide('slow');
                    $('#secao-relatorios').hide('slow');
                    //venis//
                    $('#editaImovelComercial').hide('slow');
                    $('#editaImovelResidencial').hide('slow');
                    $('#editaImovelRural').hide('slow');
                    $('#editaImovelTerreno').hide('slow');
                    $('.esconderDepois').show('slow');
                    //venis//
                }

                function mostraRemoveImovel(){
                    $('#secao-add-imovel').hide('slow');
                    $('#secao-edit-imovel').hide('slow');
                    $('#secao-del-imovel').show('slow');
                    $('#secao-list-imovel').hide('slow');
                    $('#mostrarSlide').hide('slow');
                    $('#mostrarContatos').hide('slow');
                    $('#mostrarSobre').hide('slow');
                    $('#secao-relatorios').hide('slow');
                    //venis//
                    $('.esconderDepois').show('slow');
                    //venis//
                }

                function mostraListaImovel(){
                    $('#secao-list-imovel').show('slow');
                    $('#secao-add-imovel').hide('slow');
                    $('#secao-edit-imovel').hide('slow');
                    $('#secao-del-imovel').hide('slow');
                    $('#mostrarSlide').hide('slow');
                    $('#mostrarContatos').hide('slow');
                    $('#mostrarSobre').hide('slow');
                    $('#secao-relatorios').hide('slow');
                    //venis//
                    $('.esconderDepois').show('slow');
                    //venis//
                }

                function mostraSlide(){
                    $('#mostrarSlide').show('slow');
                    $('#secao-add-imovel').hide('slow');
                    $('#secao-edit-imovel').hide('slow');
                    $('#secao-del-imovel').hide('slow');
                    $('#secao-list-imovel').hide('slow');
                    $('#mostrarContatos').hide('slow');
                    $('#mostrarSobre').hide('slow');
                    $('#secao-relatorios').hide('slow'); 
                }

                function mostraContato() {
                    $('#mostrarContatos').show('slow');
                    $('#secao-add-imovel').hide('slow');
                    $('#secao-edit-imovel').hide('slow');
                    $('#secao-del-imovel').hide('slow');
                    $('#secao-list-imovel').hide('slow');
                    $('#mostrarSlide').hide('slow');
                    $('#mostrarSobre').hide('slow');
                    $('#secao-relatorios').hide('slow');
                }

                function mostraSobre(){
                    $('#mostrarSobre').show('slow');
                    $('#secao-add-imovel').hide('slow');
                    $('#secao-edit-imovel').hide('slow');
                    $('#secao-del-imovel').hide('slow');
                    $('#secao-list-imovel').hide('slow');
                    $('#mostrarSlide').hide('slow');
                    $('#mostrarContatos').hide('slow');
                    $('#secao-relatorios').hide('slow');
                }

                function mostraRelatorios(){
                    $('#secao-relatorios').show('slow');
                    $('#secao-add-imovel').hide('slow');
                    $('#secao-edit-imovel').hide('slow');
                    $('#secao-del-imovel').hide('slow');
                    $('#secao-list-imovel').hide('slow');
                    $('#mostrarSlide').hide('slow');
                    $('#mostrarContatos').hide('slow');
                    $('#mostrarSobre').hide('slow');
                }
                function mostraEditaComercial(){
                    $('.esconderDepois').hide('slow');
                    $('#editaImovelComercial').show('slow');
                    $('#editaImovelResidencial').hide('slow');
                    $('#editaImovelRural').hide('slow');
                    $('#editaImovelTerreno').hide('slow');
                }
                 //venis//
                function mostraEditaResidencial(){
                    $('.esconderDepois').hide('slow');
                    $('#editaImovelComercial').hide('slow');
                    $('#editaImovelResidencial').show('slow');
                    $('#editaImovelRural').hide('slow');
                    $('#editaImovelTerreno').hide('slow');
                }
                //venis//
                //feijao//
                function mostraEditaRural(){
                    $('.esconderDepois').hide('slow');
                    $('#editaImovelComercial').hide('slow');
                    $('#editaImovelResidencial').hide('slow');
                    $('#editaImovelRural').show('slow');
                    $('#editaImovelTerreno').hide('slow');

                }function mostraEditaTerreno(){
                    $('.esconderDepois').hide('slow');
                    $('#editaImovelComercial').hide('slow');
                    $('#editaImovelResidencial').hide('slow');
                    $('#editaImovelRural').hide('slow');
                    $('#editaImovelTerreno').show('slow');
                }
                //feijao//

                // VITÃO//

                function mostraListaComercial(){
                    $('.esconderDepois').hide('slow');
                    $('#ListaImovelComercial').show('slow');
                    $('#ListaImovelResidencial').hide('slow');
                    $('#ListaImovelRural').hide('slow');
                    $('#ListaImovelTerreno').hide('slow');
                    //venis//
                     $('.esconderDepois').show('slow');
                     //venis//
                }

                // VITÃO //
                $("#menu-toggle").click(function(e) {
                    e.preventDefault();
                    $("#wrapper").toggleClass("active");
                });

                /*Scroll Spy*/
                $('body').scrollspy({ target: '#spy', offset:80});

                /*Smooth link animation*/
                $('a[href*=#]:not([href=#])').click(function() {
                    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

                        var target = $(this.hash);
                        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                        if (target.length) {
                            $('html,body').animate({
                                scrollTop: target.offset().top
                            }, 1000);
                            return false;
                        }
                    }
                });

                function mostraSessaoAddComercial(){
                    $('#addImovelComercial').show('slow');
                    $('#addImovelResidencial').hide('slow');
                    $('#addImovelTerreno').hide('slow');
                    $('#addImovelRural').hide('slow');
                    $('.esconderDepois').hide('slow');
                }

                function mostraSessaoAddResidencial(){
                    $('#addImovelResidencial').show('slow');
                    $('#addImovelComercial').hide('slow');
                    $('#addImovelTerreno').hide('slow');
                    $('#addImovelRural').hide('slow');
                    $('.esconderDepois').hide('slow');
                }

                function mostraSessaoAddTerreno(){
                    $('#addImovelTerreno').show('slow');
                    $('#addImovelResidencial').hide('slow');
                    $('#addImovelComercial').hide('slow');
                    $('#addImovelRural').hide('slow');
                    $('.esconderDepois').hide('slow');
                }

                function mostraSessaoAddRural(){
                    $('#addImovelRural').show('slow');
                    $('#addImovelResidencial').hide('slow');
                    $('#addImovelComercial').hide('slow');
                    $('#addImovelTerreno').hide('slow');
                    $('.esconderDepois').hide('slow');
                }

                function remostra(){
                    $('.esconderDepois').show('slow');
                    $('#addImovelComercial').hide('slow');
                    $('#addImovelResidencial').hide('slow');
                    $('#addImovelTerreno').hide('slow');
                    $('#addImovelRural').hide('slow');
                }
                function remostraEdita(){
                    $('#editaImovelComercial').hide('slow');
                    //venis//
                    $('#editaImovelResidencial').hide('slow');
                    $('#editaImovelRural').hide('slow');
                    //venis//
                    $('.esconderDepois').show('slow');
                }
                function remostrLista(){
                    $('#ListaImovelComercial').hide('slow');
                    //venis//
                    $('#ListaImovelResidencial').hide('slow');
                    $('#ListaImovelRural').hide('slow');
                    //venis//
                    $('.esconderDepois').show('slow');
                }
            </script>
            <script src="../js/js.js"></script>
            <script src="../js/jquery.js"></script>
            <script src="../js/bootstrap.js"></script>
            <script  src = "../libs/jquery-maskmoney-master/dist/jquery.maskMoney.min.js"  type = "text/javascript " ></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
            <script>

                jQuery("input#telefone")
                .mask("(99) 9999-9999?9")
                .focusout(function (event) {  
                    var target, phone, element;  
                    target = (event.currentTarget) ? event.currentTarget : event.srcElement;  
                    phone = target.value.replace(/\D/g, '');
                    element = $(target);  
                    element.unmask();  
                    if(phone.length > 10) {  
                        element.mask("(99) 99999-999?9");  
                    } else {  
                        element.mask("(99) 99999-9999");  
                    }  
                });
            </script>
            <script>
                function confirmacao(id, idEndereco, idTelefone, idProprietario) {
                    var resposta = confirm("Deseja remover esse imóvel?");
 
                    if (resposta == true) {
                        window.location.href = "RemoverImovel.php?idImovel="+id+"&idEndereco="+idEndereco+"&idTelefone="+idTelefone+"&idProprietario="+idProprietario;
                    }
                }
            </script>
            <script>
                function confirmacaoSlide(id, ) {
                    var resposta = confirm("Deseja remover esse slide?");
 
                    if (resposta == true) {
                        window.location.href = "RemoverSlide.php?idSlide="+id;
                    }
                }
            </script>
            <!--SCRIPT BUSCA ADM-->
            <script text="javascript">
            function ChamarLink() {
                var valorCombo = document.getElementById("tipoTop").value;

                if(valorCombo == "padrao"){
                    $('#comercial').hide('slow');
                    $('#residencial').hide('slow');
                    $('#rural').hide('slow');
                    $('#terreno').hide('slow');

                }else if(valorCombo == "comercial"){
                    $('#comercial').show('slow');
                    $('#residencial').hide('slow');
                    $('#rural').hide('slow');
                    $('#terreno').hide('slow');

                }else if(valorCombo == "residencial"){
                    $('#comercial').hide('slow');
                    $('#residencial').show('slow');
                    $('#rural').hide('slow');
                    $('#terreno').hide('slow');

                }else if(valorCombo == "rural"){
                    $('#comercial').hide('slow');
                    $('#residencial').hide('slow');
                    $('#rural').show('slow');
                    $('#terreno').hide('slow');

                }else if(valorCombo == "terreno"){
                    $('#comercial').hide('slow');
                    $('#residencial').hide('slow');
                    $('#rural').hide('slow');
                    $('#terreno').show('slow');
                }


            }
        </script>
        <!--FIM SCRIPT ADM-->
        <!--JAVASCRIPT FIM-->
    </body>

</html>
<?php
    if(isset($_POST['adicionarSlide'])){
        $dir = '../img/img-slider/' . DIRECTORY_SEPARATOR;
        $arquivo = isset($_FILES['fotosSlide']) ? $_FILES['fotosSlide'] : FALSE;

        for ($i = 0; $i < count($arquivo['size']); $i++){
            if (move_uploaded_file($arquivo['tmp_name'][$i], $dir . $arquivo['name'][$i])){
           
            }else{
                echo "<script>alert('Erro ao enviar imagem');</script>";
            }

            $caminhosTotal = $arquivo['name'][$i];        
        }
        $Add = $mysqli->query("INSERT INTO slide VALUES('','$caminhosTotal','fotoSlide')");
        if($Add){
            echo "<script>alert('Slide Adicionado com sucesso');</script>";
        }else{
            echo "<script>alert('Erro ao enviar slide');</script>";
        }

    }
?>